<?php
namespace App\Controllers\Admin;
use App\Database\Connection\Connection;
use App\Facades\Facades;
use App\Libraries\Auth;
use App\Libraries\CSRF;
use App\Libraries\FileUpload;
use App\Libraries\Mail;
use App\Libraries\Request;
use App\Libraries\Session;
use App\Libraries\ValidateRequest;
use App\Models\Admins\Admin;
use App\Views\View;
use App\models\users\User;
use SendGrid\Mail\Mail as SENDGREDMAIL;



//new Connection();


class AdminController
{

    public function __construct()
    {



    }

    public function index(){
        $users=User::all();
        View::renderTemplate('admin/pages/index',compact('users'));
    }


    public function sendmail()
    {

        $email = new \SendGrid\Mail\Mail();
        $email->setFrom("admin@blem.co.ke", "BLEM ENTERTAINMENT");
        $email->setSubject("CONTACT");
        $email->addTo('njengaj275@gmail.com', "JOHN");
        $email->addContent(

            "text/html", "<strong>Thank you for contacting us we will get back to you soon enough</strong>"
        );
        $sendgrid = new \SendGrid(getenv('SENDGRID_API_KEY'));
        try {
//            $response = $sendgrid->send($email);


            if ($sendgrid->send($email)){
                Facades::redirect('');
                Facades::flash('success_message_contact', 'Thank you for contacting us we will get back to you soon enough', 'Recieved');
            };



//            print $response->statusCode() . "\n";
//            print_r($response->headers());
//            print $response->body() . "\n";
        } catch (Exception $e) {
            echo 'Caught exception: '. $e->getMessage() ."\n";
        }


    }





    public function create()
    {
        $staffs=Admin::all();
        $errors=[];
        View::renderTemplate('admin/pages/create_admin',compact('staffs','errors'));
    }



    public function store(){

        $staffs=Admin::all();

        if (Request::has('post')){

            $request=Request::get('post');
            if (CSRF::verifyCSRFToken($request->CSRFToken)){

                $rules=[

                    'name'=>['required'=>true,
                        'minLength'=>3,
                        'mixed'=>true,
                        ],
                    'email'=>['required'=>true,
                        'mixed'=>true,
                        'email'=>true,
                    ],

                    'password'=>['required'=>true,
                        'mixed'=>true,
                        'minLength'=>6,
                    ],


                    'image'=>['required'=>true,
                    ],

                ];



                $validate= new ValidateRequest();
                $validate->abide($_POST, $rules);

                $file=Request::get('file');


//                var_dump($file->photo->size);
//                exit();



                $file_error = [];
//
//                var_dump($file) ;
//                exit();

                isset($file->photo->name) ? $filename=$file->photo->name :$filename='';

//                $filename=$file->photo->name;




                    $errors=[];

                if ($validate->hasError()){

                    $response=$validate->getErrorMessages();

                    count($file_error)? $errors=array_merge($response,$file_error): $errors=$response;


                    View::renderTemplate('admin/pages/create_admin',compact('errors','staffs'));exit;
                }



                $ds=DIRECTORY_SEPARATOR;

//                isset($file->photo->tmp_name) ? $temp_file=$file->photo->tmp_name :$temp_file='';


                if ($file->photo->tmp_name){
                    $temp_file=$file->photo->tmp_name;
                    $image_path=FileUpload::move($temp_file,"uploads{$ds}admins{$ds}images",$filename)->path();

                }else{


                    if (empty($filename)){

                        $file_error['adminImage']=['The admin image is required'];





                    } else if (!FileUpload::isImage($filename)){


                        $file_error['adminImage']=['The admin image is invalid'];

                    }


                    if(!FileUpload::fileSize($file->photo->size)){

                        $file_error['adminImage']=['The uploaded image is too big please upload a maximum of 2MB image'];

                    }
                }








                $admin= new Admin();

                $admin->name=$request->name;
                $admin->email=$request->email;
                $admin->password=  password_hash($request->password,PASSWORD_DEFAULT);
                if ($file->photo->tmp_name){
                    $admin->image=$image_path;
                }

               if ($admin->save()){

                   Request::refresh();

                   View::renderTemplate('admin/pages/create_admin',compact('errors','staffs'));
               } else{

                   echo "something bad happened";
               };


            }else{

                echo "invalid token";


            }


        }



    }


    public function edit($id)
    {




        if (Admin::where('id',$id)->get()->first()){

                $staff=Admin::where('id',$id)->get()->first();

                    $errors=[];

            View::renderTemplate('admin/pages/edit_admin',compact('staff','errors'));
        }





    }
        public function update($id){




        }


}


























