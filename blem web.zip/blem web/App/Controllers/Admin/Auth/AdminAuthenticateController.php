<?php
/**
 * Created by PhpStorm.
 * User: Home-Tech_Server
 * Date: 9/26/2019
 * Time: 1:17 PM
 */

namespace App\Controllers\Admin\Auth;


use App\Libraries\Auth;
use App\Facades\Facades;
use App\Models\Admins\Admin;

class AdminAuthenticateController
{



    public function login(){

        Auth::getAdmin();

        if (Auth::getAdmin()) {
            Facades::redirect('admin_dashboard');
        };




        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            //   process the admin Login form

            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);


            $data = [

                'email'             =>  trim($_POST['email']),
                'password'          =>  trim($_POST['password']),
                'email_error'       =>  '',
                'password_error'    =>  '',
                'admin_remember' =>        isset($_POST['admin_remember'])

            ];


            if (empty($data['email'])) {

                $data['email_error'] = 'Email is required';

            } elseif (filter_var($data['email'], FILTER_VALIDATE_EMAIL) == false) {

                $data['email_error'] = 'Email is invalid';

            } elseif (!Admin::findAdminByEmail($data['email'])) {

                $data['admin_remember'] = $admin_remember = isset($_POST['admin_remember']);

                $data['email_error'] = 'email does not exists in the system';
            }

            if (empty($data['password'])) {

                $data['password_error'] = 'password is required';
            }

            $admin_remember = isset($_POST['admin_remember']);

            if (
                empty($data['email_error']) &&
                empty($data['password_error'])
            ) {

                //proceed to login admin

                $admin = Admin::AdminAuthenticate($data['email'], $data['password']);


                if ($admin) {

                    Auth::createAdminSession($admin,$admin_remember);
                    Facades::redirect(Auth::return_to_intended());




                } else {
                    $data = [
                        'email' => $data['email'],
                        'remember' => $admin_remember,
                        'password_error' => 'Password Incorrect',
                        'remember' => $admin_remember

                    ];
                    View::renderTemplate('admin/auth/login', compact('data'));
                }
            } else {


                View::renderTemplate('admin/auth/login', compact('data'));
            }
        } else {



            //Load the Login form
            $data = [
                'email' => "",
                'password' => "",
                'remember' => "",
                'email_error' => "",
                'password_error' => "",
            ];
            //load view
            View::renderTemplate('admin/auth/login', compact('data'));
        }
    }



}