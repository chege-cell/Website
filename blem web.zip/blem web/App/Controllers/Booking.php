<?php

/**
 * Created by PhpStorm.
 * User: Home-Tech_Server
 * Date: 8/5/2019
 * Time: 4:38 PM
 */

namespace App\Controllers;

use App\Libraries\BaseController;
use Carbon\Carbon;
use App\Facades\Token;
use App\Models\User;
use App\Facades\Facades;
use App\Libraries\Auth;
use App\Libraries\View;

class Booking extends BaseController
{

    public function bookingAction()
    {
        $users = User::getListedUsers();

        // var_dump($user);
        // exit();

        // $data = [
        //     'user' => User::getListedUsers(),
        // ];

        View::renderTemplate('users/pages/booking', compact('users'));
    }
}
