<?php
/**
 * Created by PhpStorm.
 * User: Home-Tech_Server
 * Date: 8/26/2019
 * Time: 4:35 PM
 */

namespace App\Controllers\Landing;
use App\Libraries\Auth;
use App\Views\view;

class LandingController
{


    public function index()
    {
        Auth::getUser();

        $cookie = $_COOKIE['remember'] ?? 'false';
        if ($cookie) {
            Auth::loginFromRememberCookie();
        }

        $data=[

            'name'=>'',
            'message_error'=>'',
            'email'=>'',
            'message'=>'',
            'name_error'=>'',
        ];


        View::renderTemplate('index', compact('data'));
    }



}