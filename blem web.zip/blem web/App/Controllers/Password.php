<?php
/**
 * Created by PhpStorm.
 * User: Home-Tech_Server
 * Date: 7/28/2019
 * Time: 11:58 AM
 */

namespace App\Controllers;

use App\Facades\Facades;
use App\Models\User;
use App\Models\users\User as NUser;
use App\Libraries\BaseController;
use App\Libraries\View;

class Password extends BaseController
{


    public function forgotAction(){


        $data=[

            'email'=>''
        ];

        View::renderTemplate('users/pages/auth/password',compact('data'));
    }


    public function requestRessetAction(){


        if ($_SERVER['REQUEST_METHOD'] == 'POST') {


            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            $data = [

                'email' => trim($_POST['email']),
                'email_error' => '',

            ];

            if (empty($data['email'])) {

                $data['email_error'] = 'Email is required';
            } elseif (filter_var($data['email'], FILTER_VALIDATE_EMAIL) == false) {

                $data['email_error'] = 'Email is invalid';
            } elseif (!User::findUserByEmail($data['email'])) {
                $data['remember'] = $remember = isset($_POST['remember']);

                $data['email_error'] = 'email does not exists in the system';
            }

            if (empty($data['email_error'])){

                User::sendPasswordReset($data['email']);
                Facades::flash('success_message', 'Please Check Your email', 'Reset');
                Facades::redirect('login');

            }else{

                View::renderTemplate('users/pages/auth/password', compact('data'));
            }
        }

    }

    public function resetAction(){

        $token=$this->route_prams['token'];

        $user=User::findByPasswordReset($token);

        if ($user){

            $data=[

                'token'=>$user->password_reset_hash,
                'email'=>$user->email
            ];

            View::renderTemplate('users/pages/auth/reset_password',compact('data'));
        }else{

            View::renderTemplate('users/pages/auth/tokeninvalid');
        }
    }



    public function resetPasswordAction(){


        if ($_SERVER['REQUEST_METHOD'] == 'POST') {


            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            $data = [

                'password' => trim($_POST['password']),
                'token' => trim($_POST['token']),
                'email' => trim($_POST['email']),
                'password_confirm' => trim($_POST['password_confirm']),
                'password_error' => '',
                'password_confirm_error' => '',


            ];


            if (empty($data['password'])) {

                $data['password_error'] = 'password is required';
            }

            if (empty($data['password_confirm'])) {

                $data['password_confirm_error'] = 'password must be confirmed';
            }

            if ($data['password'] != $data['password_confirm']) {

                $data['password_error'] = 'password must match confirmation';
            }
            if (strlen($data['password']) < 6) {

                $data['password_error'] = 'password must be 6 and above characters';
            }

            if (preg_match('/.*[a-z]+.*/i', $data['password'] === 0)) {

                $data['password_error'] = 'password must have one small letter';
            }

            if (preg_match('/.*[A-Z]+.*/i', $data['password'] === 0)) {

                $data['password_error'] = 'password must have one capital letter';
            }

            if (preg_match('/.*\d+.*/i', $data['password'] === 0)) {

                $data['password_error'] = 'password must have one digit ';
            }


            if (empty($data['password_error']) && empty($data['password_confirm_error'])) {

                $user=User::findByPasswordReset($data['token']);

//                var_dump($user);

                if ($user) {

                    if (User::resetPassword($data['password'], $data['email'])) {

                        Facades::flash('success_message', 'PasswordController reset Successfully', 'Reset');
                        Facades::redirect('login');

                    }
                }else{

                   View::renderTemplate('users/pages/auth/tokeninvalid');
                }


            }else{

                View::renderTemplate('users/pages/auth/reset_password',compact('data'));
            }


        }

    }


    protected function getUserOrExit($token){


        $user=User::finsByPasswordReset($token);

        if ($user){

           return $user;

        }else{

            View::renderTemplate('users/pages/auth/tokeninvalid');
        }

    }


    public function emailVerification(){

     $user=NUser::verifyEmail($this->route_prams['token']);


     var_dump($user);

//     if ($user){
//         Facades::flash('success_message', 'Email Verified Successfully You can now login', 'Verified','bg-success');
//         Facades::redirect('login');
//     }else{
//
//         View::renderTemplate('users/pages/auth/tokeninvalid');
//
//     }




}


}