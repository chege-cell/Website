<?php
/**
 * Created by PhpStorm.
 * User1: User-Tech_Server
 * Date: 7/18/2019
 * Time: 5:09 PM
 */

namespace App\Controllers;
use Illuminate\Database\Capsule\Manager as Capsule;
use App\Facades\Facades;
use App\Libraries\Auth;
use App\Libraries\View;
use App\Facades\Mail;
use App\Libraries\BaseController;

class Users extends BaseController
{

    public function indexAction(){


        if ( !Auth::getUser()){
                Auth::intended();
                    Facades::redirect('login');
        }else{

            $data=[

                'email'=>''


            ];

            $user=Capsule::table('users')->first();

            View::renderTemplate('users/account/index',compact('data','user'));
        }





    }



}