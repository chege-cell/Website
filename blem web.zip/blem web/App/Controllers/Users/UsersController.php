<?php
/**
 * Created by PhpStorm.
 * User: Home-Tech_Server
 * Date: 8/26/2019
 * Time: 4:49 PM
 */

namespace App\Controllers\Users;
use Carbon\Carbon;
use App\Libraries\Auth;
use App\Views\view;
use App\Facades\Facades;
use App\Models\users\User;
use App\Libraries\Request;
use App\Libraries\CSRF;
use App\Libraries\FileUpload;
use App\Facades\Token;
class UsersController
{


    public function __construct()
    {
        //

    }

    public function index(){
        if ( !Auth::getUser()){
            Auth::intended();
            Facades::redirect('login');
        }else{

            $data=[

                'email'=>''
            ];

            $user=User::where('id',$_SESSION['user_id'])->get()->first();

            View::renderTemplate('users/account/index',compact('data','user'));
        }

    }



    public function login(){

        Auth::getUser();

        if (Auth::getUser()) {
            //            View::renderTemplate('users/account/index', compact('data'));
            Facades::redirect('home');
        };



        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            //   process the Login form

            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            $data = [

                'email'             =>  trim($_POST['email']),
                'password'          =>  trim($_POST['password']),
                'email_error'       =>  '',
                'password_error'    =>  '',
                'remember' =>        isset($_POST['remember'])

            ];


            if (empty($data['email'])) {

                $data['email_error'] = 'Email is required';
            } elseif (filter_var($data['email'], FILTER_VALIDATE_EMAIL) == false) {

                $data['email_error'] = 'Email is invalid';
            } elseif (!User::findUserByEmail($data['email'])) {
                $data['remember'] = $remember = isset($_POST['remember']);

                $data['email_error'] = 'email does not exists in the system';
            }

            if (empty($data['password'])) {

                $data['password_error'] = 'password is required';
            }

            $remember = isset($_POST['remember']);

            if (
                empty($data['email_error']) &&
                empty($data['password_error'])
            ) {

                //proceed to login

                $user = User::Authenticate($data['email'], $data['password']);
                //                $remember = isset($_POST['remember']);

                if ($user) {


                    if ($user->validated) {
                        //User is loged in create session
                        Auth::createUserSession($user, $remember);
                        //redirect user to their respective page
                        Facades::redirect(Auth::return_to_intended());
                    } else {

                        Facades::flash('success_message', 'Your email is not verified yet check your email to verify first', 'Unverified', 'bg-danger');
                        Facades::redirect('login');
                    }
                } else {
                    $data = [
                        'email' => $data['email'],
                        'remember' => $remember,
                        'password_error' => 'PasswordController Incorrect',
                        'remember' => $remember

                    ];
                    View::renderTemplate('users/pages/login', compact('data'));
                }
            } else {


                View::renderTemplate('users/pages/login', compact('data'));
            }
        } else {



            //Load the Login form
            $data = [

                'email' => "",
                'password' => "",
                'remember' => "",
                'email_error' => "",
                'password_error' => "",
            ];
            //load view
            View::renderTemplate('users/pages/login', compact('data'));
        }
    }



    public function register()
    {
//        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            if (Request::has('post')){
                $request = Request::get('post');
                $file=Request::get('file');
                isset($file->cover_pic->name) ? $file1name=$file->cover_pic->name :$file1name='';
                isset($file->profile_pic->name) ? $file2name=$file->profile_pic->name :$file2name='';


                    $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);


                    //   process the register form

                    $data = [
                        'user_name' => trim($_POST['user_name']),
                        'email' => trim($_POST['email']),
                        'password' => trim($_POST['password']),
                        'password_confirm' => trim($_POST['password_confirm']),
                        'genre' => trim($_POST['genre']),
                        'experience' => trim($_POST['experience']),
                        'city' => trim($_POST['city']),
                        'stage_name' => trim($_POST['stage_name']),
                        'phone' => trim($_POST['phone']),
                        'url' => trim($_POST['url']),
                        'profession' => trim($_POST['profession']),
                        'charge' => trim($_POST['charge']),
                        'gender' => trim($_POST['gender']),
                        'country' => trim($_POST['country']),
                        'description' => trim($_POST['description']),
                        'register_date' => Carbon::now(),
                        'terms' => isset($_POST['terms']),

                        'profile_pic' => trim($_FILES['profile_pic']['name']),
                        'profile_type' => trim($_FILES['profile_pic']['type']),
                        'profile_size' => trim($_FILES['profile_pic']['size']),


                        'cover_pic' => trim($_FILES['cover_pic']['name']),
                        'cover_type' => trim($_FILES['cover_pic']['type']),
                        'cover_size' => trim($_FILES['cover_pic']['size']),


                        'validated' => 0,
                        'listed' => 0,

                        'user_name_error' => '',
                        'email_error' => '',
                        'password_error' => '',
                        'password_confirm_error' => '',
                        'genre_error' => '',
                        'experience_error' => '',
                        'city_error' => '',
                        'stage_name_error' => '',
                        'phone_error' => '',
                        'url_error' => '',
                        'profession_error' => '',
                        'charge_error' => '',
                        'gender_error' => '',
                        'country_error' => '',
                        'description_error' => '',
                        'terms_error' => '',
                    ];


                    $terms = isset($_POST['terms']);

                    if (!$terms) {
                        $data['terms_error'] = "You must accept the terms";
                    }

                    if (empty($data['description'])) {

                        $data['description_error'] = 'description is required';
                    }

                    if (empty($data['country'])) {

                        $data['country_error'] = 'country is required';
                    }

                    if (strlen($data['gender']) < 1) {

                        $data['gender_error'] = 'gender is required';
                    }

                    if (empty($data['charge'])) {

                        $data['charge_error'] = 'charges is required';
                    }

                    if (strlen($data['profession']) < 1) {

                        $data['profession_error'] = 'profession is required';
                    }
                    //

                    if (empty($data['url'])) {

                        $data['url_error'] = 'Url is required';
                    }


                    if (empty($data['phone'])) {

                        $data['phone_error'] = 'phone is required';
                    }
                    //
                    if (empty($data['stage_name'])) {

                        $data['stage_name_error'] = 'stage name is required';
                    }


                    if (empty($data['city'])) {

                        $data['city_error'] = 'city is required';
                    }
                    //
                    if (strlen($data['experience']) < 1) {

                        $data['experience_error'] = 'experience is required';
                    }
                    //
                    if (empty($data['genre'])) {

                        $data['genre_error'] = 'Genre is required';
                    }
                    if (empty($data['user_name'])) {

                        $data['user_name_error'] = 'Username is required';
                    }

                    if (empty($data['email'])) {

                        $data['email_error'] = 'Email is required';
                    } elseif (filter_var($data['email'], FILTER_VALIDATE_EMAIL) == false) {

                        $data['email_error'] = 'Email is invalid';
                    } elseif (User::findUserByEmail($data['email'])) {

                        $data['email_error'] = 'That email already exists';
                    }

                    if (empty($data['password'])) {

                        $data['password_error'] = 'password is required';
                    }

                    if (empty($data['password_confirm'])) {

                        $data['password_confirm_error'] = 'password must be confirmed';
                    }

                    if ($data['password'] != $data['password_confirm']) {

                        $data['password_error'] = 'password must match confirmation';
                    }
                    if (strlen($data['password']) < 6) {

                        $data['password_error'] = 'password must be 6 and above characters';
                    }

                    if (preg_match('/.*[a-z]+.*/i', $data['password'] === 0)) {

                        $data['password_error'] = 'password must have one small letter';
                    }

                    if (preg_match('/.*[A-Z]+.*/i', $data['password'] === 0)) {

                        $data['password_error'] = 'password must have one capital letter';
                    }

                    if (preg_match('/.*\d+.*/i', $data['password'] === 0)) {

                        $data['password_error'] = 'password must have one digit ';
                    }


                    if (
                        empty($data['user_name_error']) &&
                        empty($data['email_error']) &&
                        empty($data['password_error']) &&
                        empty($data['password_confirm_error']) &&
                        empty($data['genre_error']) &&
                        empty($data['experience_error']) &&
                        empty($data['city_error']) &&
                        empty($data['stage_name_error']) &&
                        empty($data['phone_error']) &&
                        empty($data['url_error']) &&
                        empty($data['profession_error']) &&
                        empty($data['charge_error']) &&
                        empty($data['gender_error']) &&
                        empty($data['country_error']) &&
                        empty($data['terms_error']) &&
                        empty($data['description_error'])
                    ) {





                        if (CSRF::verifyCSRFToken($request->CSRFToken)) {
                            //proceed to register

                            $ds=DIRECTORY_SEPARATOR;

                            $image_path1=NULL;
                            $image_path2=NULL;

                            if ($file->cover_pic->tmp_name){
                                $temp_file=$file->cover_pic->tmp_name;
                                $image_path1=FileUpload::move($temp_file,"uploads{$ds}users{$ds}images",$file1name)->path();
                            }

                            if ($file->profile_pic->tmp_name){
                                $temp_file=$file->profile_pic->tmp_name;
                                $image_path2=FileUpload::move($temp_file,"uploads{$ds}users{$ds}images",$file2name)->path();

                            }

                                $user=new User();
                                $token = new Token();
                                $user->name        =$request->user_name;
                                $user->email            =$request->email;
                                $user->password         =password_hash($request->password,PASSWORD_DEFAULT)   ;
                                $user->experience       =$request->experience;
                                $user->city             =$request->city;
                                $user->gender           =$request->gender;
                                $user->stage_name       =$request->stage_name;
                                $user->phone            =$request->phone;
                                $user->genre            =$request->genre;
                                $user->url              =$request->url;
                                $user->profession       =$request->profession;
                                $user->country          =$request->country;
                                $user->charge           =$request->charge;
                                $user->description      =$request->description;
                                $user->cover_pic        =$image_path1;
                                $user->profile_pic      =$image_path2;
                                $user->register_date    =Carbon::now();
                                $user->validated        = 0;
                                $user->listed           = 0;
                                $user->activation_hash  = $token->getHash();
                                if ($user->save()){

                                    if (User::sendActivationEmail($request->email)){

                                        var_dump($user);exit();

                                    }
                                }



//






                            //pasist user data into the database


//                if (User::register($data)) {
//
//                    User::sendActivationEmail($data['email']);
//
//                    Facades::flash('success_message', 'Please wait Check your email To verify your account', 'Registered');
//
//                    Facades::redirect('login');
//
//                    //Return a success message to the user and or redirect to another page
//
//                } else {
//                    // return an internal error message 500
//                }

                        }else{

//                            Facades::redirect('register');

                    View::renderTemplate('users/pages/register', compact('data'));
                        }


                        } else {

                            View::renderTemplate('users/pages/register', compact('data'));
                        }









































        }






        else {


            if (Auth::getUser()) {
                View::renderTemplate('index', compact('data'));
            } else {


                //Load the register form
                $data = [


                    'user_name'         =>  '',
                    'email'             =>  '',
                    'password'          =>  '',
                    'password_confirm'  =>  '',
                    'genre'             =>  '',
                    'experience'        =>  '',
                    'city'              =>  '',
                    'stage_name'        =>  '',
                    'phone'             =>  '',
                    'url'               =>  '',
                    'profession'        =>  '',
                    'charge'            =>  '',
                    'gender'            =>  '',
                    'country'           =>  '',
                    'description'       =>  '',
                    'terms'             =>  '',
                    'terms_error'       =>''
                ];
                View::renderTemplate('users/pages/register', compact('data'));
            }
        }
    }




    public function logout(){

        Auth::logout();

    }

}