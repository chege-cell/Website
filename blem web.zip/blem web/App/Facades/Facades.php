<?php


namespace App\Facades;
use Carbon\Carbon;
class Facades
{

    //Simple redirect
    public static function redirect($page){

    header('Location: '.URL_ROOT. '/'. $page);

//        header('Location: '.$_SERVER['REQUEST_URI']);
    }

       public static function flash($name = '',$des='', $message = '', $class = 'bg-success')
        {
            if (!empty($name)) {
                if (!empty($message) && empty($_SESSION[$name])) {
                    if (!empty($_SESSION[$name])) {
                        unset($_SESSION[$name]);
                    }

                    if (!empty($_SESSION[$name . '_class'])) {
                        unset($_SESSION[$name . '_class']);
                    }

                    $_SESSION[$name] = $message.":".$des ;
                    $_SESSION[$des]=    $des;
                    $_SESSION[$name . '_class'] = $class;


                } else

                    if (empty($message) && !empty($_SESSION[$name])) {
                    $class = !empty($_SESSION[$name . '_class']) ? $_SESSION[$name . '_class'] : '';
//                    echo '<p class="' . $class . '" id="msg-flash">' . $_SESSION[$name] . '</p>';
                echo $des;

                    $_SESSION[$des]=    $des;

            echo '
                    <div class="toast ml-auto fixed-top border-0 "  role="alert" data-delay="700" data-autohide="false" style="border-radius: 0;z-index: 2000">
                        <div class="toast-header">
                        
                            <strong class="mr-auto text-success"></strong>
              
                            
                            <small class="text-muted">'.$_SESSION[$des].Carbon::now().' </small>
                            <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                        <div class="toast-body '.$class.' ">
                            <p class="text-white">'. $_SESSION[$name].'</p>
                        </div>
                    </div>
                ';

                    unset($_SESSION[$name]);
                    unset($_SESSION[$des]);
                    unset($_SESSION[$name . '_class']);
                }
            }
        }
}