<?php
/**
 * Created by PhpStorm.
 * User1: User-Tech_Server
 * Date: 7/20/2019
 * Time: 8:50 AM
 */

namespace App\Facades;


class Token
{


    protected $token;


    public function __construct($token='')
    {

        if ($token){
            $this->token=$token;
        }else{
            $this->token=bin2hex(random_bytes(16));
        }


    }


//    public function __toString()
//    {
//        // TODO: Implement __toString() method.
//        try {
//
//            return (string) $this->token;
//        }
//        catch (Exception $exception){
//
//            return "";
//        }
//    }


    /**
     * @return string
     */
    public function getToken()
    {
        return $this->token;
    }


    /**
     * @return string hashed token
     */
    public function getHash()
    {
        return hash_hmac('sha256',$this->token,"secret");
    }


}