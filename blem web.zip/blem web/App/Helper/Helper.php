<?php

use Carbon\Carbon;
use App\Models\users\User;
use App\Models\Admins\Admin;

//check if the user is already loged in
function AuthUser()
{
    if (isset($_SESSION['user_id'])) {
        return true;
    } else {
        return false;
    }
}


//check if the user is already loged in
function AuthAdmin()
{
    if (isset($_SESSION['admin_id'])) {
        return true;
    } else {
        return false;
    }
}



function flash($name = '',$des='', $message = '', $class = 'bg-success')
{
    if (!empty($name)) {
        if (!empty($message) && empty($_SESSION[$name])) {
            if (!empty($_SESSION[$name])) {
                unset($_SESSION[$name]);
            }

            if (!empty($_SESSION[$name . '_class'])) {
                unset($_SESSION[$name . '_class']);
            }

            $_SESSION[$name] = $message.":".$des ;
            $_SESSION[$des]=    $des;
            $_SESSION[$name . '_class'] = $class;


        } else

            if (empty($message) && !empty($_SESSION[$name])) {
                $class = !empty($_SESSION[$name . '_class']) ? $_SESSION[$name . '_class'] : '';
//                    echo '<p class="' . $class . '" id="msg-flash">' . $_SESSION[$name] . '</p>';
                echo $des;

                $_SESSION[$des]=    $des;

                echo '
                    <div class="toast ml-auto fixed-top border-0 " role="alert" data-delay="700" data-autohide="false" style="border-radius: 0">
                        <div class="toast-header">
                        
                            <strong class="mr-auto text-success"></strong>
              
                            
                            <small class="text-muted">'.$_SESSION[$des].Carbon::now().' </small>
                            <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                        <div class="toast-body '.$class.' ">
                            <p class="text-white">'. $_SESSION[$name].'</p>
                        </div>
                    </div>
                ';

                unset($_SESSION[$name]);
                unset($_SESSION[$des]);
                unset($_SESSION[$name . '_class']);
            }
    }
}