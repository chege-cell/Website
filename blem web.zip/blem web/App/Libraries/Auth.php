<?php

namespace App\Libraries;
use App\Models\Admins\Admin;
use App\Models\User;
use App\Facades\Facades;
use App\Models\RememberedLogin;
class Auth
{

//admin Authentication
public static function createAdminSession($admin,$remember)
{
    //regenerate the session id to avoid session fixation

    session_regenerate_id(true);

    //add user properties into the session
    $_SESSION['user_id'] = $admin->id;
    $_SESSION['user_email'] = $admin->email;
    $_SESSION['user_name'] = $admin->name;
    $_SESSION['profile_pic'] = $admin->profile_pic;
    $_SESSION['status'] = $admin->validated;
    if ($remember) {
        Admin::rememberLogin();
    }
}




    public static function getAdmin()
    {
        if (isset($_SESSION['admin_id'])) {

            return Admin::findAdminById($_SESSION['admin_id']);

        } else {

            return static::loginAdminFromRememberCookie();

        }
    }

//end of Admin Authentication



//User Authentication
public static function createUserSession($user,$remember)
{
        //regenerate the session id to avoid session fixation
        session_regenerate_id(true);

        //add user properties into the session
        $_SESSION['user_id'] = $user->id;
        $_SESSION['user_email'] = $user->email;
        $_SESSION['user_name'] = $user->name;
        $_SESSION['profile_pic'] = $user->profile_pic;
        $_SESSION['status'] = $user->validated;
        if ($remember) {

            User::rememberLogin();
        }
}


    //check if the user is already loged in
    public static function userIsLoged()
    {
        if (isset($_SESSION['user_id'])) {
            return true;
        } else {
            return false;
        }
    }


    // flash the user session out
    public static function logout()
    {
        unset($_SESSION['user_id']);
        unset($_SESSION['user_email']);
        unset($_SESSION['user_name']);
        unset($_SESSION['profile_pic']);
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();

            setcookie(
                session_name(),
                '',

                time() - 4200,
                $params['path'],
                $params['domain'],
                $params['secure'],
                $params['httponly']
            );
        }
        session_destroy();
        static::forgetLogin();
        Facades::redirect('');
    }


    public function intended()
    {
        $_SESSION['intended_url'] = $_SERVER['REQUEST_URI'];
    }


    public static function return_to_intended()
    {
        $_SESSION['intended_url'] = $_SERVER['REQUEST_URI'];
        if ($_SESSION['intended_url']){
            $url = $_SESSION['intended_url'];
            $url = rtrim($url, '/');
            $url = filter_var($url, FILTER_SANITIZE_URL);
            $url = explode('/', $url);

            $url = ($url[2]);

            return $url ?? '';
        }


    }



    public static function getUser()
    {
        if (isset($_SESSION['user_id'])) {

            return User::findUserById($_SESSION['user_id']);

        } else {

            return static::loginFromRememberCookie();

        }
    }




    public static function loginFromRememberCookie()
    {
        $cookie = $_COOKIE['remember'] ?? false;

        if ($cookie) {
            $remembered_login = RememberedLogin::findByToken($cookie);
            if ($remembered_login) {
                $user =User::findUserById($remembered_login->user_id);
                static::createUserSession($user, false);
                return $user;
            }
        }
    }


    protected static function forgetLogin(){

        $cookie=$_COOKIE['remember'] ?? false;

        if ($cookie){

            $remembered_login=RememberedLogin::findByToken($cookie);

            if ($remembered_login){
                RememberedLogin::deleteCookie($cookie);
            }
        }
    }

    //End of User authentciation
}




































