<?php
/**
 * Created by PhpStorm.
 * User: Home-Tech_Server
 * Date: 8/27/2019
 * Time: 8:57 PM
 */

namespace App\Libraries;

class CSRF
{


    public static function _token()
    {
//        Session::remove('CSRFToken');
        if (!Session::has('CSRFToken')){
            $randomToken=base64_encode(openssl_random_pseudo_bytes(32));
            Session::save('CSRFToken',$randomToken);
        }else{

            return Session::get('CSRFToken');
        }


    }


    public static function verifyCSRFToken($requestToken)
    {


            if (Session::has('CSRFToken') && Session::get('CSRFToken')===$requestToken){

                Session::remove('CSRFToken');


                return true;
            }


            return false;



    }

}