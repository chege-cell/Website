<?php
/**
 * Created by PhpStorm.
 * User: Home-Tech_Server
 * Date: 8/5/2019
 * Time: 4:18 PM
 */

namespace App\Libraries;
use Illuminate\Database\Capsule\Manager as Capsule;

class Database
{

 public function Database(){
     $capsule = new Capsule();
 }

}