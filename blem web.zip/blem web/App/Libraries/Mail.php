<?php
/**
 * Created by PhpStorm.
 * User: Home-Tech_Server
 * Date: 8/28/2019
 * Time: 3:05 PM
 */

namespace App\Libraries;
use App\Views\View;

class Mail
{

    public static function sendmail($user_email, $subject, $name, $template,$text)
    {
        $email = new \SendGrid\Mail\Mail();
        $email->setFrom("admin@blem.co.ke", "BLEM ENTERTAINMENT");
        $email->setSubject($subject);
        $email->addTo($user_email, $name);
        $email->addContent("text/plain", $text);
        $email->addContent("text/html",$template);
        $sendgrid = new \SendGrid(getenv('SENDGRID_API_KEY'));
        try {


            $response = $sendgrid->send($email);


            if ($response){

                return true;
            }else{
                return false;
            }

//            print $response->statusCode() . "\n";
//            print_r($response->headers());
//            print $response->body() . "\n";



        } catch (Exception $e) {
            echo 'Caught exception: '. $e->getMessage() ."\n";
        }


    }






//public function __construct()
//{
//
//    $this->mail=new PHPMailer;
//    $this->setUp();
//
//}
//
//
//
//    public function setUp()
//    {
//        $this->mail->isSMTP();
//        $this->mail->Mailer='smtp';
//        $this->mail->SMTPAuth=true;
//        $this->mail->SMTPSecure='tls';
//
//        $this->mail->Host= getenv('SMTP_HOST');
//        $this->mail->Port= getenv('SMTP_PORT');
//
//        $environment=getenv('APP_ENV');
//
//        if ($environment==='local'){ $this->mail->SMTPDebug=2;}
//
//        $this->mail->Username= getenv('EMAIL_USERNAME');
//        $this->mail->Password= getenv('EMAIL_PASSWORD');
//        $this->mail->isHTML(true);
//        $this->mail->SingleTo=true;
//
//
//
//        $this->mail->From=getenv('ADMIN_EMAIL');
//
//        $this->mail->FromName=getenv('BLEM ENTERTAINMENT');
//
//
//}
//
//
//    public function send($data){
//
//    $this->mail->addAddress($data['to'],$data['name']);
//    $this->mail->Subject=$data['subject'];
//    $this->mail->Body= View::make($data['view'],array('data'=>$data['body'])) ;
//    return $this->mail->send();
//
//
//
//}


}