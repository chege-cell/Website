<?php 
/*PDO database class
*connect to the databse
*create prepared statements
*Bind values
*return rows and results
*/
namespace App\Libraries;
use Illuminate\Database\Capsule\Manager as Capsule;
use PDO;
class Migration
{
    private $host=DB_HOST;
    private $user=DB_USER;
    private $pass=DB_PASS;
    private $dbname=DB_NAME;

    private $db;
    private $stmt;
    private $error;

    public function __construct()
    {

        $capsule=new Capsule;

        $capsule->addConnection([
        'driver'=>getenv('DB_DRIVER'),
        'host'=>getenv('DB_HOST'),
        'database'=>getenv('DB_NAME'),
        'username'=>getenv('DB_USERNAME'),
        'password'=>getenv('DB_PASSWORD'),
        'carset'=>'utf8',
        'collation'=>'utf8_unicode',
        'prefix'=>'',

    ]);

        $capsule->setAsGlobal();
        $capsule->bootEloquent();



        $dsn='mysql:host='.$this->host. ';dbname=' . $this->dbname;

        $options=array(
                    PDO::ATTR_PERSISTENT=>true,
                    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION
         );

//Create PDO instance
try {
    $this->db=new PDO($dsn, $this->user, $this->pass,$options);

} catch (PDOException $e) {
    $this->error=$e->getMessage();
        echo $this->error;
}

    }
    //prepare statements with querry
    public function query($sql)
    {
       $this->stmt=$this->db->prepare($sql);
    }

      //Bind value and parameters

    public function bind($param,$value,$type=null)
    {
        if (is_null($type)) {
            switch (true) {
                case is_int($value):
                    $type=PDO::PARAM_INT;
                    break;

                    case is_bool($value):
                    $type=PDO::PARAM_BOOL;
                    break;

                    case is_null($value):
                    $type=PDO::PARAM_NULL;
                    break;
                default:
                    $type=PDO::PARAM_STR;
            }
        }

        $this->stmt->bindValue($param,$value,$type);
    }

    //execute the prepared statement
    public function execute()
    {
       return $this->stmt->execute();
    }

    //Get results set as array of objets
    public function resultSet()
    {
        $this->execute();
        return $this->stmt->fetchAll(PDO::FETCH_OBJ);
    }

    //get single object
    public function single()
    {
        $this->execute();
        return $this->stmt->fetch(PDO::FETCH_OBJ);
    }

    //get the row count
    public function rowCount()
    {
        return $this->stmt->rowCount();
    }

    public function fetcClass()
    {
        $this->execute();
        return $this->stmt->setFetchMode(PDO::FETCH_CLASS,get_called_class());
    }


    public function Database(){
        $capsule = new Capsule();
    }



}



















