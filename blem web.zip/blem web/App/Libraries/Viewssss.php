<?php
namespace App\Libraries;
use Jenssegers\Blade\Blade;
use App\Facades\Facades;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Blade as Buf;
class View
{
    public static function renderer($view,$args=[])
    {
        extract($args,EXTR_SKIP);
        $file="../App/Views/$view"; #path to views folder
        if (is_readable($file)) {
           require $file;
        }else {
            echo "The View $file not found";
        }
    }






    // render Views using Blade
    public static function renderTemplate($template, $data = [])
    {
       echo static::returnTemplate($template,$data);

    }



    // render Views using Blade
    public static function returnTemplate($template, $data = [])
    {
        $blade = new Blade('../App/Views', '../cache');
        $file = '../App/Views/' . $template . '.blade.php';
        if (file_exists($file)) {
            return $blade->render($template, $data);

        }

//        else {
//            echo "The view" . " " . $template . " " . "Does not exist in path" . " " . $file;
//        }


    }




    public static function render($template,$args=[])
    {
        $twig=null;
        if ($twig===null) {
            $loader = new \Twig_Loader_Filesystem('../App/Views');
            $twig = new \Twig_Environment($loader);
        }
        echo $twig->render($template,$args);
    }


}