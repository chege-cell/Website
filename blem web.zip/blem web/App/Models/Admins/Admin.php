<?php
/**
 * Created by PhpStorm.
 * User: Home-Tech_Server
 * Date: 8/29/2019
 * Time: 11:45 AM
 */
namespace App\models\Admins;
use App\Libraries\Migration;
use Illuminate\Database\Eloquent\SoftDeletes;
namespace App\Models\Admins;
use App\Facades\Token;
use App\Libraries\Auth;
use Illuminate\Database\Eloquent\Model;

class Admin extends Model
{

// use SoftDeletes;

    protected $fillable = ['name', 'email', 'phone', 'password','image'];
// protected $dates = ['deleted_at'];
    public $timestamps = true;

    protected $hidden = [
        'password'
    ];





    //Admin Authenticate
    public static function AdminAuthenticate($email, $password)
    {

        $admin = static::findAdminByEmail($email);
        if ($admin) {

            if (password_verify($password, $admin->password)) {
                return $admin;
            }
            return false;
        }
    }



    //Find admin by Email
    public static function findAdminByEmail($email)
    {
        $admin= Admin::where('email',$email)->get()->first();
        if ($admin){
            return $admin;
        }else{
            return false;
        }
    }






    public function rememberLogin()
    {

        $token = new Token();

        $hashed_token = $token->getHash();

        $remeber_token = $token->getToken();

        $expiry_timestamp = time() + (60 * 60 * 24 * 30); //30 days



        $admin_remember_token=new Remember();

        $admin_remember_token->token_hash=$hashed_token;
        $admin_remember_token->admin_id=Auth::getAdmin();
        $admin_remember_token->expires_at=date('Y-m-d H:i:s', $expiry_timestamp);

        if ($admin_remember_token->save()){

            setcookie('admin_remember', $remeber_token, $expiry_timestamp, '/');
        }
    }



    public static function findAdminById($id)
    {
        $admin= Admin::where('admin_id',$id)->get()->first();

        if ($admin){

            return $admin;
        }else{
            return false;
        }
    }


}




















