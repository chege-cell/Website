<?php
/**
 * Created by PhpStorm.
 * User: Home-Tech_Server
 * Date: 9/26/2019
 * Time: 12:53 PM
 */

namespace App\Models\Admins;


use Illuminate\Database\Eloquent\Model;

class Remember extends Model
{

    protected $table='admin_remember_tokens';

    protected $fillable = ['token_hosh', 'admin_id', 'expires_at'];

}