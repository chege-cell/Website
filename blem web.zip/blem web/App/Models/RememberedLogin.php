<?php
/**
 * Created by PhpStorm.
 * User1: User-Tech_Server
 * Date: 7/21/2019
 * Time: 9:11 AM
 */

namespace App\Models;


use App\Libraries\Migration;
use App\Facades\Token;
use App\Libraries\Auth;
class RememberedLogin extends Migration
{



public static function findByToken($token){

    $token =new Token($token);

    $token_hash=$token->getHash();


//    var_dump($token);
//    var_dump($token_hash);
//    exit();


    $db=new Migration();
    $db->query('SELECT * FROM remember_tokens WHERE token_hash=:token_hash');
    $db->bind(':token_hash',$token_hash);
    $db->fetcClass();
    return $db->single();

}


public static function deleteCookie($cookie){

    $db= new Migration();

    $db->query('DELETE FROM remember_tokens where token_hash=:token_hash');
    $db->bind(':token_hash', static::findByToken($cookie)->token_hash);
    $db->execute();
}



}