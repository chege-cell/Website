<?php

/**
 * Created by PhpStorm.
 * User1: User-Tech_Server
 * Date: 7/18/2019
 * Time: 1:55 PM
 */

namespace App\Models;

use App\Facades\Mail;
use App\Facades\Token;
use App\Libraries\Auth;
use App\Libraries\Migration;
use App\views\View;
use App\Facades\Facades;
use Carbon\Carbon;
use PDO;

class User extends Migration
{

    public function register($data)
    {

        $token = new Token();
        $hashed_token = $token->getHash();

        $db = new Migration();
        $db->query('INSERT INTO users (name, email,password,genre,experience,city,stage_name,phone,url,profession,charge,gender,country,validated,description,profile_pic,cover_pic,register_date,activation_hash,listed) 
      VALUES (:user_name, :email, :password,:genre,:experience,:city,:stage_name,:phone,:url,:profession,:charge,:gender,:country,:validated,:description,:profile_pic,:cover_pic,:register_date,:activation_hash,:listed)');

        // Bind Values
        $db->bind(':user_name',     $data['user_name']);
        $db->bind(':email',         $data['email']);
        $db->bind(':password',      $data['password']);
        $db->bind(':genre',         $data['genre']);
        $db->bind(':experience',    $data['experience']);
        $db->bind(':city',          $data['city']);
        $db->bind(':stage_name',    $data['stage_name']);
        $db->bind(':phone',         $data['phone']);
        $db->bind(':url',           $data['url']);
        $db->bind(':profession',    $data['profession']);
        $db->bind(':charge',        $data['charge']);
        $db->bind(':gender',        $data['gender']);
        $db->bind(':country',       $data['country']);
        $db->bind(':validated',     $data['validated']);
        $db->bind(':description',   $data['description']);
        $db->bind(':profile_pic',   $data['profile_pic']);
        $db->bind(':cover_pic',     $data['cover_pic']);
        $db->bind(':register_date', $data['register_date']);
        $db->bind(':listed',        $data['listed']);



        $db->bind(':activation_hash', $hashed_token);
        if ($db->execute($data)) {
            return true;
        } else {

            return false;
        }
    }


    //User Authenticate
    public static function Authenticate($email, $password)
    {

        $user = static::findUserByEmail($email);
        if ($user) {

            if (password_verify($password, $user->password)) {
                return $user;
            }
            return false;
        }
    }




    public static function getListedUsers()
    {
        $db = new Migration();

        $db->query('SELECT * FROM users WHERE listed=:listed');
        $db->bind(':listed', 1);
        return  $db->resultSet();
    }


    public static function findUserByEmail($email)
    {

        $db = new Migration();

        $db->query('SELECT * FROM users WHERE email=:email');
        $db->bind(':email', $email);

        if ($db->single()) {
            $user = $db->single();
            return $user;
        } else {
            return false;
        }
    }





    public static function findUserById($id)
    {
        $db = new Migration();

        $db->query('SELECT * FROM users WHERE id=:id');
        $db->bind(':id', $id);
        $row = $db->single($id);

        if ($db->rowCount() > 0) {

            return $row;
        } else {
            return false;
        }
    }



    public function rememberLogin()
    {
        $db = new Migration();

        $token = new Token();

        $hashed_token = $token->getHash();

        $remeber_token = $token->getToken();

        $expiry_timestamp = time() + (60 * 60 * 24 * 30); //30 days


        $db->query('INSERT INTO remember_tokens(token_hash,user_id,expires_at)
                    VALUES (:token_hash,:user_id, :expires_at)');

        $db->bind(':token_hash', $hashed_token);

        $db->bind(':user_id', Auth::getUser()->id);

        $db->bind(':expires_at', date('Y-m-d H:i:s', $expiry_timestamp));

        if ($db->execute()) {

            setcookie('remember', $remeber_token, $expiry_timestamp, '/');
        }
    }

    public static function sendPasswordReset($email)
    {
        $user = static::findUserByEmail($email);
        if ($user) {


            if (User::startPasswordReset($email)) {

                User::sendPasswordResetEmail($email);
            }
        }
    }


    public function startPasswordReset($email = '')
    {
        $db = new Migration();
        $token = new Token();
        $hashed_token = $token->getHash();
        $password_reset_token = $token->getToken();

        $expiry_timestamp = time() + (60 * 60 * 2); //2 hours
        $db->query('UPDATE users SET password_reset_hash=:token_hash,password_reset_exp=:expires_at WHERE email=:email');

        $db->bind(':token_hash', $hashed_token);

        $db->bind(':email', $email);

        $db->bind(':expires_at', date('Y-m-d H:i:s', $expiry_timestamp));
        $db->fetcClass();
        return $db->execute();
    }

    protected function sendPasswordResetEmail($email)
    {


        $db = new Migration();
        $db->query('SELECT  password_reset_hash FROM users WHERE email=:email');

        $db->bind(':email', $email);
        $user = $db->single();

        $password_reset_token = $user->password_reset_hash;

        $token = new Token($password_reset_token);

        $token_value = $token->getToken();

        $url = URL_ROOT . '/passwordReset/' . $token_value;

        $text = "Please click on the following Link to reset your password";
        $html = View::returnTemplate('users/pages/auth/reset_email', compact('url'));
        $subject = "PasswordController Reset";

        Mail::send($email, $subject, $text, $html);
    }



    public static function findByPasswordReset($token)
    {
        $token = new Token($token);
        $hashed_token = $token->getHash();
        $token_reset = $token->getToken();
        $db = new Migration();
        $db->query('SELECT * FROM users WHERE password_reset_hash=:password_reset_hash');

        $db->bind(':password_reset_hash', $token_reset);
        $user = $db->single();

        if ($user) {
            if (strtotime($user->password_reset_exp) > time()) {

                return $user;
            }
        }
    }


    public function resetPassword($password, $email)
    {
        $db = new Migration();
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        $db->query('UPDATE users SET password=:password_hash,password_reset_hash=NULL ,password_reset_exp=NULL WHERE  email=:email');
        $db->bind(':password_hash', $password_hash);
        $db->bind(':email', $email);
        return $db->execute();
    }



    public function sendActivationEmail($email)
    {
        $db = new Migration();
        $db->query('SELECT  activation_hash FROM users WHERE email=:email');

        $db->bind(':email', $email);
        $user = $db->single();

        $token = new Token($user->activation_hash);

        $unhashed_token = $token->getToken();


        $url = URL_ROOT . '/emailVerification/' . $unhashed_token;

        $text = "Please click on the following Link Verify your email";
        $html = View::returnTemplate('users/pages/auth/verify_email', compact('url'));
        $subject = "Email Verification";

        Mail::send($email, $subject, $text, $html);
    }


    public static function verifyEmail($token)
    {

        $token = new Token($token);

        $email_verification_token = $token->getToken();


        $db = new Migration();

        $db->query('UPDATE users SET validated=1,activation_hash=NULL WHERE activation_hash=:hashed_token');
        $db->bind(':hashed_token', $email_verification_token);

        if ($db->execute()) {
            return true;
        } else {
            return false;
        }
    }
}
