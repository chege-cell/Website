<?php

namespace App\models\users;
use App\Libraries\Migration;
use Illuminate\Database\Eloquent\Model;
use App\Facades\Token;
use App\Views\View;
use App\Libraries\Mail;
use Illuminate\Database\Eloquent\SoftDeletes;

class User extends Model
{

    // use SoftDeletes;



    protected $fillable = ['name' ,'email','password','experience','city','gender','stage_name','phone','genre','Url','profession','country','charge','description','cover_pic','profile_pic','hashed_token', 'validated', 'register_date', 'listed', 'deleted_at', 'updated_at'];

     protected $dates = ['deleted_at'];
    public $timestamps = true;

    protected $hidden = [
        'password'
    ];



    public static function findUserByEmail($email)
    {
        $db = new Migration();
        $db->query('SELECT * FROM users WHERE email=:email');
        $db->bind(':email', $email);

        if ($db->single()) {
            $user = $db->single();
            return $user;
        } else {
            return false;
        }
    }



    //    User Authenticate
    public static function Authenticate($email, $password)
    {

        $user = static::findUserByEmail($email);
        if ($user) {

            if (password_verify($password, $user->password)) {
                return $user;
            }
            return false;
        }
    }




    public static function sendActivationEmail($email)
    {
        $user=User::where('email',$email)->get()->first();

        $token = new Token($user->activation_hash);
        $name= $user->name;

        $unhashed_token = $token->getToken();


        $url = URL_ROOT . '/emailVerification/' . $unhashed_token;

        $text = "Please click on the following Link Verify your email";
        $template = View::returnTemplate('users/pages/auth/verify_email', compact('url'));
        $subject = "Email Verification";

        Mail::sendmail($email, $subject, $name, $template,$text);
    }





    public static function verifyEmail($token)
    {

        $token = new Token($token);

        $email_verification_token = $token->getToken();


        var_dump($email_verification_token);exit();


        $db = new Migration();

        $db->query('UPDATE users SET validated=1,activation_hash=NULL WHERE activation_hash=:hashed_token');
        $db->bind(':hashed_token', $email_verification_token);

        if ($db->execute()) {
            return true;
        } else {
            return false;
        }
    }





}