<?php
$router = new AltoRouter();



//Admin routes
$router->map( 'GET', '/blem/admin', 'App\Controllers\Admin\AdminController@index' ,'Admin_index');


$router->map( 'GET', '/blem/admin/create', 'App\Controllers\Admin\AdminController@create' ,'Admin_create');

$router->map( 'post', '/blem/admin/store', 'App\Controllers\Admin\AdminController@store' ,'Admin_store');

$router->map( 'GET', '/blem/admin/edit/[i:id]', 'App\Controllers\Admin\AdminController@edit' ,'Admin_edit');

$router->map( 'POST', '/blem/admin/update', 'App\Controllers\Admin\AdminController@update' ,'Admin_update');




$router->map( 'GET|POST', '/blem/admin/sendmail', 'App\Controllers\Admin\AdminController@sendmail' ,'Admin_sendmail');






$router->map( 'GET', '/blem/', 'App\Controllers\Landing\LandingController@index' ,'Landing_index');

$router->map( 'GET', '/blem/home', 'App\Controllers\Users\UsersController@index' ,'Users_index');



//user management
$router->map( 'GET|POST', '/blem/login', 'App\Controllers\Users\UsersController@login' ,'Users_login');
$router->map( 'GET|POST', '/blem/logout', 'App\Controllers\Users\UsersController@logout' ,'Users_logout');
$router->map( 'GET|POST', '/blem/register', 'App\Controllers\Users\UsersController@register' ,'Users_register');




$router->map( 'GET|POST', '/blem/password', 'App\Controllers\Users\PasswordController@forgot' ,'Users_forgot_password');

$router->map( 'GET|POST', '/blem/passwordReset/[a:token]', 'App\Controllers\Users\PasswordController@reset' ,'Users_reset');
$router->map( 'GET|POST', '/blem/emailVerification/[a:token]', 'App\Controllers\Users\PasswordController@emailVerification' ,'Users_emailVerification');
















//$router->map( 'GET|POST', '/blem/register', 'App\Controllers\Users\UsersController@register' ,'Users_register');

//manage password resets

//$router->add('password',['controller'=>'password','action'=>'forgot']);

//$router->map( 'GET|POST', '/blem/password', 'App\Controllers\Users\PasswordController@forgot' ,'Users_forgot_password');

//$router->add('requestResset',['controller'=>'password','action'=>'requestResset']);
$router->map( 'GET|POST', '/blem/requestResset', 'App\Controllers\Users\PasswordController@requestResset' ,'Users_requestResset');
//$router->add('passwordReset/{token:[\da-f]+}',['controller'=>'password','action'=>'reset']);

//$router->map( 'GET|POST', '/blem/passwordReset/[token]', 'App\Controllers\Users\PasswordController@reset' ,'Users_reset');


//$router->add('resetPassword',['controller'=>'password','action'=>'resetPassword']);

$router->map( 'GET|POST', '/blem/resetPassword', 'App\Controllers\Users\PasswordController@resetPassword' ,'Users_resetPassword');

//booking Page management
//$router->add('booking',['controller'=>'booking','action'=>'booking']);

$router->map( 'GET|POST', '/blem/booking', 'App\Controllers\Booking\BookingController@login' ,'Customer_booking');




//
//#Add the routes to the routing table
//
//$router->add('',['controller'=>'Home','action'=>'index']);
//$router->add('posts',['controller'=>'Posts','action'=>'index']);
//$router->add('posts/new',['controller'=>'Posts','action'=>'new']);
//$router->add('login',['controller'=>'Home','action'=>'login']);
//
//
////admin routes
//
//$router->add('admin',['controller'=>'AdminController\AdminController','action'=>'index']);
//
//
//
//
////manage password resets
//
//$router->add('password',['controller'=>'password','action'=>'forgot']);
//
//$router->add('requestResset',['controller'=>'password','action'=>'requestResset']);
//
//$router->add('passwordReset/{token:[\da-f]+}',['controller'=>'password','action'=>'reset']);
//
//$router->add('resetPassword',['controller'=>'password','action'=>'resetPassword']);
//
////booking Page management
//$router->add('booking',['controller'=>'booking','action'=>'booking']);
//
//
//
//
//
//$router->add('home',['controller'=>'Users','action'=>'index']);
//
//
//$router->add('logout',['controller'=>'Home','action'=>'logout']);
//
//$router->add('register',['controller'=>'Home','action'=>'register']);
//$router->add('emailVerification/{token:[\da-f]+}',['controller'=>'password','action'=>'emailVerification']);
//
//
//
//$router->add('{controller}/{action}');
//
//$router->add('{controller}/{id:\d+}/{action}');
//$router->add('admin/{controller}/{action}',['namespace'=>'AdminController']);

