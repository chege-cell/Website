<?php
/**
 * Created by PhpStorm.
 * User: Home-Tech_Server
 * Date: 8/26/2019
 * Time: 4:10 PM
 */

namespace App\Routing;
use App\Views\view;
use AltoRouter;
class RouterDispatcher
{


    protected $match;
    protected $controller;
    protected $method;

    public function __construct(AltoRouter $router)
    {

        $this->match=$router->match();

        $match=$router->match();


        if ($this->match){

            list($controller,$method)=explode('@', $this->match['target']);
            $this->controller=$controller;
            $this->method=$method;


            if (is_callable(array(new $this->controller,$this->method))){
                call_user_func_array(array(new $this->controller,$this->method),array($this->match['params']));

            }else{

                View::renderTemplate('errors/404',compact('method','controller')) ;
            }

        } else{

            View::renderTemplate('errors/pagenotfound');
        }


    }



}