@extends("admin.master")
@section('title'){{'AdminController'}}@endsection

@section('content')
    <div class="mt-5 ">
        <div class="container-fluid">
            @yield('content')
        </div>
    </div>

@endsection