<nav class="navbar navbar-expand navbar-dark bg-dark  navbar-top fixed-top">
    <a class="navbar-brand text-uppercase  text-expanded" href="{{URL_ROOT}}">
        <img src="{{URL_ROOT}}/public/img/logo/logo.png" width="100" height="30" alt=""></a>
    <span><img class="img-fluid rounded-circle rounded-5" width="30" height="10" ></span>&nbsp;&nbsp;<strong class="text-white">By Alfred Kakuli +254 791 699 262</strong></div></a></div>
    <button class="btn btn-link btn-sm text-white bg-warning order-1 border-0 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars">lll</i>
    </button>
    <!-- Navbar -->
    <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown no-arrow">

            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php ?>
                <img  class="img-fluid rounded-circle " src={{("public/upload/staff/images/")}}  alt="person" style="width: 20px; height: 20px">
            </a>

            <div class="dropdown-menu bg-dark text-white dropdown-menu-right border-0" aria-labelledby="userDropdown" style="border-radius: 0">
                <a class="dropdown-item text-white " href="#"><span><i class="fa fa-user"></i></span>&nbsp;&nbsp; Profile Settings</a>

                <a class="dropdown-item text-white" href="#"><span><i class="fa fa-gears"></i></span>&nbsp;&nbsp;App Settings</a>

                <div class="dropdown-divider"></div>
                <a class="dropdown-item text-white" href="#" data-toggle="modal" data-target="#logoutModal"><i class="fa fa-power-off"></i>&nbsp;&nbsp;Logout</a>

                <a class="dropdown-item text-white" href="" onclick="event.preventDefault();
                                document.getElementById('admin_logout_form').submit();">
                </a>

                <a href="{{URL_ROOT}}" class="dropdown-item text-white"><span><i class="fa fa-gears"></i></span>&nbsp;&nbsp;Site</a>
                <form id="admin_logout_form" action="" method="post" style="display: none;">
                </form>

            </div>
        </li>
    </ul>
</nav>


<!--logout Modal -->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel text center fa fa-poweroff text-danger">Log out</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-center text-warning">
                You are about to leave the application. Are you sure?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-dismiss="modal">Go back</button>

                </button>


                <a href="{{URL_ROOT}}/logout">

                    <button class="btn btn-danger">Logout</button>
                </a>
            </div>
        </div>
    </div>
</div>



<!--Pro app Modal -->
<div class="modal fade" id="pro_app_show" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog border-0" role="document" style="border-radius: 0">
        <div class="modal-content" style="border-radius: 0">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel text center fa fa-poweroff text-danger">Pro App</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-center text-warning">
                <h3>This is a premium app feature</h3>
            </div>
            <div class="modal-footer mx-auto">
                <p class="text-info">Call: 0791 699 262</p>
                <hr>
                <p>Email: alfredkakuli@gmail.com</p>
            </div>
            <button type="button" class="btn btn-success btn-block" data-dismiss="modal" style="border-radius: 0">Ok</button>
        </div>
    </div>
</div>