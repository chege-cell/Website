<ul class="sidebar navbar-nav ">
    <li class="nav-item active">
        <a class="nav-link" href="#">
            <i class="fas  fa-fw fa-tachometer-alt" style="color: #EF6C00"></i>
            <span>Home</span>
        </a>
    </li>

    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-school"  style="color: #F50057"></i>
            <span>Account</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class=" dropdown-item " href="#">
                <i class="fa fa-fw fa-building text-info"></i>
                <span>Profile</span>
            </a>
        </div>
    </li>


    <li class="nav-item active">
        <a class="nav-link" href="{{APPROOT}}">
            <i class="fas  fa-fw fa-tachometer-alt" style="color: #EF6C00"></i>
            <span>Users</span>
        </a>
    </li>



</ul>