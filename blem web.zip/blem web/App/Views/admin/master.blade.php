
<!DOCTYPE html>

<head>
    <meta charset="utf-8">
    <title>{{SITENAME}}|@yield('title')</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="{{URL_ROOT}}/public/css/bootstrap.min.css" />
    <link rel="stylesheet" href="{{URL_ROOT}}/public/css/blem.css" />
    <link rel="stylesheet" href="{{URL_ROOT}}/public/css/all.css" />
    <link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">


</head>
<body>




{{--start navbar--}}
{{--<nav class="navbar navbar-expand-md navbar-light">--}}
    {{--<button class="navbar-toggler ml-auto mb-2 bg-light" type="button" data-toggle="collapse" data-target="#blem_Admin_navbar">--}}
        {{--<span class="navbar-toggler-icon"></span>--}}
    {{--</button>--}}

    {{--<div class="collapse navbar-collapse" id="blem_Admin_navbar">--}}
        {{--<div class="container-fluid">--}}
            {{--<div class="row">--}}
                {{--Admin_side_navbar--}}

                {{--<div class="col-lg-2 admin_side_navbar fixed-top">--}}

                    {{--<a href="#" class="navbar-brand text-white d-block mr-auto text-center py-3 mb-4 bottom_border ">BLEM</a>--}}
                    {{--<div class="bottom_border pb-3 text-center">--}}
                        {{--<img class="rounded-circle mr-3 " src="{{URL_ROOT}}/public/img/wozap.PNG" width="50" alt="">--}}
                        {{--<a href="#"class="text-white">Alfred Kakuli</a>--}}
                    {{--</div>--}}


                    {{--<ul class="navbar-nav flex-column align-items-lg-start  ">--}}

                        {{--<li class="nav-item"><a href="#" class="nav-link text-white pb-2  mt-4 sidebar_link"><i class="fas fa-home text-light fa-lg mr-3"></i>Dashboard</a>--}}
                        {{--</li>--}}



                        {{--<li class="nav-item"><a href="#" class="nav-link text-white pb-2  sidebar_link"><i class="fas  fa-lock text-light fa-lg mr-3"></i>Account</a>--}}
                        {{--</li>--}}


                        {{--<li class="nav-item"><a href="#" class="nav-link text-white pb-2  sidebar_link"><i class="fas  fa-user text-light fa-lg mr-3"></i>Users</a>--}}
                        {{--</li>--}}

                    {{--</ul>--}}


                {{--</div>--}}





                {{--End of Admin_side_navbar--}}

                {{--Admin_top_navbar--}}
                {{--<div class="col-lg-10 ml-auto bg-dark fixed-top py-2">--}}
                    {{--<div class="row">--}}
                        {{--<div class="col-md-4">--}}
                            {{--<h4 class="text-light text-uppercase mb-0">Dashboard</h4>--}}
                        {{--</div>--}}

                        {{--<div class="col-md-5">--}}
                            {{--<form action="" class="input-group">--}}

                                {{--<input type="text" class="class-control search_input" placeholder="Seach">--}}
                                {{--<button type="button" class="btn btn-light search_button"><i class="fas fa-search text-danger"></i></button>--}}
                            {{--</form>--}}
                        {{--</div>--}}

                        {{--<div class="col-md-3">--}}

                        {{--</div>--}}
                    {{--</div>--}}
                {{--</div>--}}
                {{--End of Admin_top_navbar--}}

            {{--</div>--}}
        {{--</div>--}}
    {{--</div>--}}

{{--</nav>--}}
{{--end of navbar--}}




@include('admin.admin_navbar')
<div id="wrapper">
    @include('admin.admin_side_bar')
    <div id="content-wrapper">
        @yield('content')
    </div>
</div>


</body>











<script src="{{URL_ROOT}}/public/js/jquery.min.js"></script>
<script src="{{URL_ROOT}}/public/js/bootstrap.min.js"></script>
<script src="{{URL_ROOT}}/public/js/bootstrap.min.js"></script>
<script src="{{URL_ROOT}}/public/js/current-day.js"></script>
<script src="{{URL_ROOT}}/public/js/blem.js"></script>
<script src="{{URL_ROOT}}/public/js/all.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>


<script>

    $(document).ready(function(){
        $(".toast").toast('show',{
            autohide: false
        });
    });



    // $(document).ready(function(){
    //     $(".show-toast")
    //         $("#.show-toast").toast('show');
    //     });



</script>


</body>

</html>