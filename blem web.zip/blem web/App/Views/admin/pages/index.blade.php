@extends("admin.admin_index")
@section('title'){{'AdminController'}}@endsection

@section('content')
<div class="container-fluid mt-5">
    @if($users)
    <div class="card " style="border-radius: 0">
        <div class="card-block">
            <div class="table-responsive border-0">
                <table class="table table-hover">
                    <thead>
                        <tr style="border-width: 0px;font-size: 10px">
                            <th>NAME</th>
                            <th>STAGE NAME</th>
                            <th>EMAIL</th>
                            <th>PHONE</th>
                            <th>RESIDENCE</th>
                            <th>CHARGE</th>
                            <th>URL</th>
                            <th>DESCRIPTION</th>
                            <th>GENDER</th>
                            <th>GENRE</th>
                            <th>PROFESSION</th>
                            <th>EXPERIENCE</th>
                            <th>PHOTO</th>
                            <th class="text-danger">DEL</th>
                            <th class="text-danger">STATUS</th>
                        </tr>
                    </thead>
                    <tbody>


                    @php  @endphp
                        @foreach($users as $user)
                        {{$user->email}}
                        @endforeach


                        <tr style="font-size: 9px">
                            <td>name</td>
                            <td>stage Name</td>
                            <td>Email</td>
                            <td>Phone</td>
                            <td>Residence</td>

                            <td>Charge</td>
                            <td><a href="#">Url</a></td>
                            <td>Description</td>
                            <td>Gender</td>
                            <td>Genre</td>
                            <td>Profession</td>
                            <td>Experience</td>
                            <td><img class="img-fluid rounded-circle" width="10" height="10" src=""></td>



                            <td>
                                <form class="form-inline form-delete" action="" method="POST" id="formDeleteuser">
                                    <button type="button" class="btn btn-sm btn-danger delete_user glyphicon glyphicon-trash" data-title="Delete Staff" data-target="#confirmDelete" data-message="are you sure you want to delete  ?" data-toggle="modal" &laquo; id="delete_user" name="confirm_user_delete">&nbsp;&nbsp;...Pending</button>
                                </form>
                            </td>



                            <td>
                                <form class="form-inline form-delete" action="" method="POST" id="formDeleteuser">
                                    <button type="button" class="btn btn-sm btn-danger delete_user glyphicon glyphicon-trash" data-title="Delete Staff" data-target="#confirmDelete" data-message="are you sure you want to delete  ?" data-toggle="modal" &laquo; id="delete_user" name="confirm_user_delete"><i class="fa fa-trash"></i>&nbsp;&nbsp; Delete</button>
                                </form>
                            </td>

                        </tr>




                    </tbody>


                </table>
            </div>
        </div>
    </div>
    @endif
</div>
@endsection