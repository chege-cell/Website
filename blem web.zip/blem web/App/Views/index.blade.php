@extends("master")
@section('title'){{'Home'}}@endsection

@section('slider')
{{--SHOW CASE SLIDER--}}

<section id="show_case">

    <div id="blem_carousel" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">

            <li class="active" data-slide-to="0" data-target="#blem_carousel"></li>
            <li class="" data-slide-to="1" data-target="#blem_carousel"></li>
            <li class="" data-slide-to="2" data-target="#blem_carousel"></li>
        </ol>

        <div class="carousel-inner">
            <div class="carousel-item carouser-image-1 active" style="background-image: url({{URL_ROOT}}/public/img/pages/intro.jpg);background-size: cover;background-repeat: no-repeat">
                <div class="container">
                    <div class="carousel-caption d-none d-sm-block text-right mb-5">

                        <div class="row">
                            <div class="col-md-6 text-left">
                                <h1 class="display-3">Heading One</h1>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. A consectetur cum doloribus est eum exercitationem fugit impedit magnam pariatur ut!</p>
                                <a href="" class="btn btn-danger btn-lg">Join us today</a>
                            </div>

                            <div class="col-md-6">

                            </div>
                        </div>


                    </div>
                </div>
            </div>

            <div class="carousel-item carouser-image-1" style="background-image: url({{URL_ROOT}}/public/img/pages/introc.jpg);background-size: cover;background-repeat: no-repeat">
                <div class="container">
                    <div class="carousel-caption d-none d-sm-block text-right mb-5">
                        <div class="row">
                            <div class="col-md-6 text-left">
                                <h1 class="display-3">Heading Two</h1>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. A consectetur cum doloribus est eum exercitationem fugit impedit magnam pariatur ut!</p>
                                <a href="" class="btn btn-danger btn-lg">Join us today</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



        </div>


        <a href="#blem_carousel" data-slide="prev" class="carousel-control-prev">
            <span class="carousel-control-prev-icon"></span>
        </a>


        <a href="#blem_carousel" data-slide="next" class="carousel-control-next">
            <span class="carousel-control-next-icon"></span>
        </a>

    </div>

</section>



{{--END OF SHOWCASE SLIDER--}}
@endsection
@section('content')
<section>
    <example-component></example-component>
</section>
@endsection