<?php

use App\Facades\Facades; ?>
<!DOCTYPE html>

<head>
    <meta charset="utf-8">
    <title>{{SITENAME}}|@yield('title')</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="{{URL_ROOT}}/public/css/blem.css" />
    <link rel="stylesheet" href="{{URL_ROOT}}/public/css/app.css" />
    <link rel="stylesheet" href="{{URL_ROOT}}/public/css/animate.css" />



</head>

<body>
    <div class="app" id="app">
        {{Facades::flash('success_message')}}
        <div class="container_custom bg-dark mb-5">
            <nav class="navbar navbar_main navbar-dark navbar-expand-sm fixed-top bg-dark" id="mainNav" style="border-bottom: 3px solid grey">
                <div class="container">
                    <a class="navbar-brand text-uppercase  text-expanded" href="{{URL_ROOT}}">
                        <img src="{{URL_ROOT}}/public/img/logo/logo.png" width="100" height="50" alt=""></a>
                    <button data-toggle="collapse" data-target="#navbar_Responsive" class="navbar-toggler text-white bg-warning" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon text-white border-0"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbar_Responsive">
                        <ul class="nav navbar-nav mr-auto ml-auto text-center">
                            <li class="nav-item active" role="presentation"><a class="nav-link" href="{{URL_ROOT}}">Home</a></li>
                            <li class="nav-item" role="presentation"><a class="nav-link" href="{{URL_ROOT}}/pages/about">About us</a></li>
                            <li class="nav-item" role="presentation"><a class="nav-link" href="{{URL_ROOT}}/">Contact us</a>
                            <li class="nav-item" role="presentation"><a class="nav-link" href="{{URL_ROOT}}/booking">Book</a>
                            </li>

                            <li class="nav-item dropdown" role="presentation">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Booking</a>
                                <div class="dropdown-menu bg-dark border-0 text-center" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="nav-link" href="index.html">Book</a>
                                </div>
                            </li>
                        </ul>


                        @if(isset($_SESSION['user_id']))

                        <ul class="nav navbar-nav ml-auto text-center">
                            <li class="nav-item" role="presentation"><a class="nav-link" href="{{URL_ROOT}}/home">{{$_SESSION['user_name']}}</a></li>
                            <li class="nav-item" role="presentation"><a class="nav-link" href="{{URL_ROOT}}/logout">Log out</a></li>
                        </ul>
                        @else
                        <ul class="nav navbar-nav ml-auto text-center">
                            <li class="nav-item" role="presentation"><a class="nav-link" href="{{URL_ROOT}}/login">Login</a></li>
                            <li class="nav-item" role="presentation"><a class="nav-link" href="{{URL_ROOT}}/register">Register</a></li>
                        </ul>
                        @endif
                    </div>
                </div>
            </nav>

            @yield('slider')

            <div id="content-wrapper">
                @yield('content')
            </div>

        </div>


    </div>

    </div>
    <script src="{{URL_ROOT}}/public/js/jquery.min.js"></script>
    <script src="{{URL_ROOT}}/public/js/app.js"></script>
    <script src="{{URL_ROOT}}/public/js/bootstrap.min.js"></script>
    <script src="{{URL_ROOT}}/public/js/current-day.js"></script>
    <script src="{{URL_ROOT}}/public/js/blem.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>



    <script>
        $(document).ready(function() {

            //show the toast for the session notification

            $(".toast").toast('show', {
                autohide: false
            });


            //login through ajax

            // $("#user_login_form").submit(function (event){
            //
            //     event.preventDefault();
            //
            //     var logInData=$(this).serialize();
            //
            //     var url=$(this).attr('action');
            //
            //     $.post(url,logInData, function(login_data) {
            //
            //         location.reload(true);
            //
            //     });
            //
            // });


            // login form validation

            $.fn.email = function() {

                var node = document.createElement("LI");

                var $this = $(this)
                var pattern = /^\w{2,15}@\w{2,15}[.]\w{2,5}([.](us|cn|fr))?$/
                var input = $this.val();
                var result = pattern.test(input);


                if (result === false) {

                    var textnode = document.createTextNode("Water");

                    $this.css({

                        'border-bottom': '2px solid red'

                    });

                    document.getElementById("email").appendChild(textnode);

                    // document.getElementById("myList").appendChild(node);

                    $('#email_feed_back').append("Email is invalid")

                    // $this.addClass('valid')
                } else {
                    // $this.addClass('invalid')
                    $this.css({

                        'border-bottom': '2px solid green'

                    });

                    $('#email_feed_back').append("Email is valid")
                }

                return result;
            };


            $('#email').on('keyup', function() {

                var isEmailValid = $('#email').email();


            });



        });
    </script>


</body>

</html>