@extends("master")
@section('title'){{'About'}}@endsection
@section('content')
<h1>THIS IS About</h1>
@endsection