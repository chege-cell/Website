@extends('users.index')

@section('content')
<div class="container-fluid">
    <div class="card mt-5 mx-auto text-center" style="border-radius: 0;">
        <div class="card-header">
            <p>Welcome {{$_SESSION['user_name']}}   &nbsp;&nbsp; ACCOUNT STATUS &nbsp;&nbsp;

    @if($_SESSION['status'])

    <span class="text-success">{{'Active'}}</span>

    @else
    <span class="text-danger">{{'Inactive'}}</span>
    @endif

            </p>
        </div>

        <div class="card-body" style="height: 200px">

        {{$user->email}}

        </div>
    </div>
    </div>

    @endsection