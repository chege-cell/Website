@extends("admin.master")
@section('title'){{'Home'}}@endsection

@section('content')

    <div class="mt-5">
        <div class="container-fluid">

            @yield('content')

        </div>
    </div>

@endsection