<?php

use App\Facades\Facades; ?>
@extends("master")
@section('title'){{'Recover Password'}}@endsection
@section('content')

<section class="page-section clearfix ">
    <div class="container text-center mt-5">
        <div class="">
            {{Facades::flash('success_message')}}
            <h4 class="text-warning">Recover Password</h4>
            <p>all fileds marked with <span class="text-danger">*</span> Are required</p>
        </div>
        <div class="card bg-transparent border-0 " style="border-radius:0;">
            <div class=" card-body border-0 bg-transparent">

                <form class=" form bg-white text-left text-dark col-md-6 mx-auto" method="POST" action="{{URL_ROOT}}/requestResset" enctype="multipart/form-data">

                    <div class="row pt-3 mx-auto justify-content-center align-items-center">
                        <div class="col-md-12">
                            <div class="form-group"><label>Emails <span class="text-danger">*</span> </label>
                                <input class="form-control {{(!empty($data['email_error']))? 'is-invalid':''}}" name="email" value="{{$data['email']}}" type="email">
                                <span class="invalid-feedback">{{$data['email_error']}}</span>
                            </div>
                        </div>

                    </div>



                    <div class=" row mx-auto">
                        <div class="col-md-12">
                            <button class="btn btn-sm float-right btn-primary mb-3 mt-3" type="submit" name="submit">Reset</button>
                            <button class="btn btn-sm float-left btn-danger mb-3 mt-3" type="reset" name="reset">Cancel</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <h4>Dont Have an Acount </h4><a href="{{URL_ROOT}}/register"><span class="btn btn-link">Register</button></a>
    </div>
</section>
@endsection