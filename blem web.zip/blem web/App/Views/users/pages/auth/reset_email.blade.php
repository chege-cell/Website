

<h1>Password Reset</h1>

<h2>Please click the link below to reset your password</h2>

{{$url}}