@extends("master")
@section('title'){{'Reset Password'}}@endsection
@section('content')
<section class="page-section clearfix mt-5">
    <div class="container-fluid text-center ">
        <div class="mt-5" style="margin-top:5px">
            <h4 class="text-warning">Reset Password</h4>
            <p class="text-light">all fileds marked with <span class="text-danger">*</span> Are required</p>
        </div>

        <div class="card border-0 bg-transparent  " style="border-radius:0;">
            <div class=" card-body border-0 bg-transparent ">

                <form class=" form bg-white text-left text-dark w-100 col-md-6 mx-auto" method="POST" action="{{URL_ROOT}}/resetPassword">
                    <div class="row pt-5 mx-auto w-100">

                        <div class="col-md-12 mb-2 mb-md-0 no-gutter">
                            <div class="form-group"><label>Password</label>
                                <input class="form-control {{(!empty($data['password_error']))? 'is-invalid':''}} text-dark" name="password" type="password">
                                <span class="invalid-feedback">{{$data['password_error']}}</span>
                            </div>



                            <div class="form-group"><label>Password Confirm</label>
                                <input class="form-control {{(!empty($data['password_confirm_error']))? 'is-invalid':''}} text-dark" name="password_confirm" type="password">
                                <span class="invalid-feedback">{{$data['password_confirm_error']}}</span>
                            </div>


                        </div>
                    </div>





                    <div class=" row mx-auto">
                        <div class="col-md-12">
                            <button class="btn btn-lg float-right btn-primary mb-3 mt-3" type="submit" name="submit">Reset</button>
                            <button class="btn btn-lg float-left btn-danger mb-3 mt-3" type="reset" name="reset">Cancel</button>
                        </div>
                    </div>

                    <input type="hidden" name="token" value="{{$data['token']}}">
                    <input type="hidden" name="email" value="{{$data['email']}}">

                </form>
            </div>
        </div>
    </div>
</section>
@endsection