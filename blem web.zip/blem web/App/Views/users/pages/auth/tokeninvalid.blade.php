<?php use App\Facades\Facades; ?>
@extends("master")
@section('title'){{'Login'}}@endsection
@section('content')

    <section class="page-section clearfix">
        <div class="container ">




            <!-- Flexbox container for aligning the toasts -->
            <div aria-live="polite" aria-atomic="true" class="d-flex justify-content-center align-items-center token_invalid"  style="min-height: 200px;">

                <!-- Then put toasts within -->
                <div class="toast" role="alert" data-delay="700" data-autohide="false" aria-live="assertive" aria-atomic="true">
                    <div class="toast-header bg-warning">
                        <strong class="mr-auto">Warning</strong>
                        <small>{{ \Carbon\Carbon::now()->diffForHumans()}}</small>
                        <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="toast-body bg-danger">
                        <p class="text-white">The Reset token You used has expired or is invalid</p>
                    </div>
                </div>
            </div>


            {{--<div class="card bg-transparent border-0 d-flex justify-content-center align-items-center " style="border-radius:0;">--}}
                {{--<div class=" card-body border-0 bg-transparent d-flex justify-content-center align-items-center">--}}

                    {{--<p class="text-warning bg-danger">The Reset token You used has expired or is invalid</p>--}}

                {{--</div>--}}
            {{--</div>--}}
            <h2>Have an Account </h2><a href="{{URL_ROOT}}/login"><button class="btn btn-primary">Login</button></a>
        </div>
    </section>
@endsection

