<h1>Email Verification</h1>

<h2>Please click the link below to Verify your email</h2>

                            {{$url}}