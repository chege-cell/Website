<?php

use App\Facades\Facades; ?>
@extends("master")
@section('title'){{'booking'}}@endsection
@section('content')





@if($users>0)
<div class="container-fluid pages-bg">

    <form class="text-center mt-4" action="">
        <div class="row text-center mx-auto mt-4">
            <h4>Filter By</h4>
            <div class="col-md-2">

                <div class="form-group">
                    <label for="dj">
                        <input name="filter" value="dj" id="dj" type="radio">&nbsp; Dj
                    </label>
                </div>
            </div>
            <div class="col-md-2">

                <div class="form-group">
                    <label for="band">
                        <input name="filter" value="band" id="band" type="radio">&nbsp; Band
                    </label>
                </div>

            </div>
            <div class="col-md-2">

                <div class="form-group">
                    <label for="experience">
                        <input name="filter" value="experience" id="experience" type="radio">&nbsp; Experience
                    </label>
                </div>

            </div>
            <div class="col-md-2">

                <div class="form-group">
                    <label for="cost">
                        <input name="filter" value="charge" id="cost" type="radio">&nbsp; Cost
                    </label>
                </div>

            </div>

        </div>



    </form>
<div class="container-fluid">
    <div class="row mx-auto text-center mb-4">



        {{--<div class="col-lg-9 ml-auto">--}}
            {{--<div class="row pt-5 mt-3 mb-5">--}}
                {{--<div class="col-sm-6 p-2">--}}
                    {{--<div class="card">--}}
                        {{--<img src="{{URL_ROOT}}/public/img/bg.jpg" alt="" class="card-img" style="border-radius:0">--}}
                        {{--<div class="card-body">--}}
                            {{--<div class="d-flex justify-content-between">--}}
                                {{--<i class="fas fa-shopping-cart fa-3x text-warning"></i>--}}
                                {{--<div class="text-right text-secondary">--}}
                                    {{--<h5>Sales</h5>--}}
                                    {{--<h3>Ksh10,000</h3>--}}
                                {{--</div>--}}
                            {{--</div>--}}
                        {{--</div>--}}
                        {{--<div class="card-footer text-secondary">--}}
                            {{--<i class="fas fa-plus mr-3"></i>--}}
                            {{--<span><button class="btn btn-primary border-0">BOOK NOW</button></span>--}}
                        {{--</div>--}}
                    {{--</div>--}}
                {{--</div>--}}
            {{--</div>--}}
        {{--</div>--}}




        @foreach($users as $user )
        <div class="col-md-3">
            <div class="card mb-4 border-0" style="border-radius:0">

                <div class="card-header" style="border-radius:0">{{$user->name}}</div>
                <img src="{{URL_ROOT}}/public/img/bg.jpg" alt="" class="card-img" style="border-radius:0">

                <p>{{$user->description}}</p>

                <div class="card-body" style="border-radius:0">
                    <p><a class="text-warning" href="{{$user->url}}">WORK</a>&nbsp; <span class=" text-warning">COST{{$user->charge}}</span></p>
                </div>

                <a href="#" class="card-footer btn btn-success btn-block text-dark bg-info border-0" style="border-radius:0">
                    BOOK NOW
                </a>

            </div>
        </div>
        @endforeach
    </div>
</div>


</div>
@endif

@endsection