<?php

use App\Facades\Facades; ?>
@extends("master")
@section('title'){{'Login'}}@endsection
@section('content')
<!-- Login section -->

<div class="container-fluid pages-bg">
<section class="page-section clearfix">

        <div class="card bg-light border-0 mb-5 " style="border-radius:0;">

            <div class="mx-auto">
                {{Facades::flash('success_message')}}

                <h2 class="text-warning display-4">Member Login</h2>
            </div>

            <div class=" card-body border-0 bg-transparent">
                <form id="user_login_form" class=" form bg-transparent text-left text-dark col-md-6 mx-auto" method="POST" action="{{URL_ROOT}}/home/login" enctype="multipart/form-data">

                    <div class="row pt-3 mx-auto justify-content-center align-items-center">
                        <div class="col-md-12 text-dark">
                            <div class="form-group py-4 mt-5">
                                <input class="form-control input {{(!empty($data['email_error']))? 'is-invalid':''}}" id="email" name="email" value="{{$data['email']}}" type="email">
                                <label class="label" for="email">Email</label>
                                <span class="invalid-feedback mt-5" id="email_feed_back">{{$data['email_error']}}</span>
                            </div>

                            <div class="form-group py-4 mt-5">
                                <input class="form-control input {{(!empty($data['password_error']))? 'is-invalid':''}}" name="password" type="password">
                                <label for="password" class="label">Password</label>
                                <span class="invalid-feedback mt-5">{{$data['password_error']}}</span>
                            </div>


                            <div class="form-group py-4 mt-5">
                                <label for="remember">
                                    <input class="form-check-label" name="remember" id="remember" @if($data['remember']) checked="checked" @endif type="checkbox">Remember Me
                                </label><span><a href="{{URL_ROOT}}/password">Forgot Password?</a></span>
                            </div>


                        </div>

                    </div>

                    <div class="row buttons-row text-white">
                        <div class=" mt-2">
                            <button class="btn btn-success  font-weight-bold text-upercase text-white login-button btn-login" type="submit">Log in</button>

                        </div>
                        <div class=" mt-2 mx-auto ">
                            <a href="{{URL_ROOT}}/register"><div class="btn btn-warning  font-weight-bold text-upercase text-white login-button btn-passforgot">Register</div></a>
                        </div>


                    </div>
                </form>

            </div>

        </div>
</section>
</div>
@endsection




































