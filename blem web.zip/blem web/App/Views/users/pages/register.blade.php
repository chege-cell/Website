@extends("master")
@section('title'){{'Register'}}@endsection
@section('content')
<section class="page-section">

    <div class="card border-0 bg-light mt-0  text-center" style="border-radius:0;">

        <div class="row text-center">
            <div class="col-md-6">
                <h2 class="text-warning">Djs Registration Page</h2>
            </div>
            <div class="col-md-6">
                <h4>Have an Acount <a class="text-warning" href="{{URL_ROOT}}/login">Login Here</a></h4>
            </div>
        </div>

        <div class=" card-body border-0 bg-transparent">

            <form class=" form bg-transparent text-left text-dark col-md-10 mx-auto" method="POST" action="{{URL_ROOT}}/register" enctype="multipart/form-data">
                <div class="row pt-5 mx-auto mb-5">

                    <div class="col-md-6 mb-2 mt-5">
                        <div class="form-group">
                            <input class="form-control input   {{(!empty($data['user_name_error']))? 'is-invalid':''}} " placeholder="User Name" name="user_name" value="{{$data['user_name']}}" type="text">
                            <label for="user_name" class="label">User Name</label>
                            <p class="invalid-feedback invalid-feedback-register mt-5">{{$data['user_name_error']}}</p>
                        </div>

                        <div class="form-group py-4 mt-5">
                            <input class="form-control input {{(!empty($data['email_error']))? 'is-invalid':''}}" name="email" placeholder="email" value="{{$data['email']}}" type="email">
                            <label for="email" class="label">Email</label>
                            <p class="invalid-feedback mt-5">{{$data['email_error']}}</p>
                        </div>

                        <div class="form-group py-4 mt-5">
                            <input class="form-control input {{(!empty($data['password_error']))? 'is-invalid':''}}" name="password" type="password" placeholder="Password">
                            <label for="password" class="label">Password</label>
                            <p class="invalid-feedback mt-5">{{$data['password_error']}}</p>
                        </div>



                        <div class="form-group py-4 mt-5">
                            <input class="form-control input {{(!empty($data['password_confirm_error']))? 'is-invalid':''}}" name="password_confirm" type="password" placeholder="Password Confirm">
                            <label for="password_confirm" class="label">Password Confirm</label>
                            <p class="invalid-feedback mt-5">{{$data['password_confirm_error']}}</p>
                        </div>





                        <div class="form-group py-4 mt-5">
                            <select class="form-control input {{(!empty($data['experience_error']))? 'is-invalid':''}}" name="experience" value="{{$data['experience']}}" type='text'>
                                <option value="{{$data['experience']}}">{{$data['experience']}}</option>
                                <option>
                                    One year and below
                                </option>
                                <option>
                                    5 years and below
                                </option>
                                <option>
                                    5 Years and above
                                </option>
                            </select>
                            <label for="experience" class="label">Experience</label>
                            <span class="invalid-feedback mt-5">{{$data['experience_error']}}</span>
                        </div>



                        <div class="form-group py-4 mt-5">
                            <input class="form-control input {{(!empty($data['city_error']))? 'is-invalid':''}}" name="city" placeholder="city" value="{{$data['city']}}" type="text">
                            <label for="city" class="label">City</label>
                            <p class="invalid-feedback mt-5">{{$data['city_error']}}</p>
                        </div>

                        <div class="form-group py-4 mt-5">
                            <select class="form-control input {{(!empty($data['gender_error']))? 'is-invalid':''}}" name="gender" value="{{$data['gender']}}" type='text'>
                                <option value="{{$data['gender']}}">{{$data['gender']}} Gender</option>
                                <option>
                                    Male
                                </option>
                                <option>
                                    Female
                                </option>
                            </select>
                            <label for="gender" class="label">Gender</label>
                            <span class="invalid-feedback mt-5">{{$data['gender_error']}}</span>
                        </div>

                    </div>

                    <div class="col-md-6 mb-2 mb-md-0 ">

                        <div class="form-group mt-5">
                            <input class="form-control input {{(!empty($data['stage_name_error']))? 'is-invalid':''}}" placeholder="Stage Name" name="stage_name" value="{{$data['stage_name']}}" type="text">
                            <label class="label" for="state_name">Stage Name</label>
                            <p class="invalid-feedback mt-5">{{$data['stage_name_error']}}</p>
                        </div>



                        <div class="form-group py-4 mt-5">
                            <input class="form-control input {{(!empty($data['phone_error']))? 'is-invalid':''}}" placeholder="Phone" name="phone" value="{{$data['phone']}}" type="tel">
                            <label class="label" for="phone">Phone</label>
                            <p class="invalid-feedback mt-5">{{$data['phone_error']}}</p>
                        </div>



                        <div class="form-group py-4 mt-5">
                            <input class="form-control input {{(!empty($data['genre_error']))? 'is-invalid':''}}" placeholder="Genre" name="genre" value="{{$data['genre']}}" type="text">
                            <label for="genre" class="label">Genre</label>
                            <p class="invalid-feedback mt-5">{{$data['genre_error']}}</p>
                        </div>


                        <div class="form-group  py-4 mt-5">
                            <input class="form-control input {{(!empty($data['url_error']))? 'is-invalid':''}}" name="url" placeholder="Url" value="{{$data['url']}}" type="url">
                            <label class="label" for="url">Url</label>
                            <span class="invalid-feedback mt-5">{{$data['url_error']}}</span>
                        </div>

                        <div class="form-group py-4 mt-5">
                            <select class="form-control input {{(!empty($data['profession_error']))? 'is-invalid':''}}" name="profession" value="{{$data['profession']}}" type='text'>
                                <option value="{{$data['profession']}}">{{$data['profession']}}</option>
                                <option>
                                    Dj
                                </option>
                                <option>
                                    Producer
                                </option>
                                <option>
                                    Dj/Producer
                                </option>
                            </select>
                            <label class="label" for="profession">Profession</label>
                            <span class="invalid-feedback mt-5">{{$data['profession_error']}}</span>
                        </div>

                        <div class="form-group py-4 mt-5">
                            <input class="form-control input {{(!empty($data['country_error']))? 'is-invalid':''}}" placeholder="Country" name="country" value="{{$data['country']}}" type="text">
                            <label for="country" class="label">Country</label>
                            <span class="invalid-feedback mt-5">{{$data['country_error']}}</span>
                        </div>

                        <div class="form-group py-4 mt-5">
                            <input class="form-control input {{(!empty($data['charge_error']))? 'is-invalid':''}}" placeholder="Charge" name="charge" value="{{$data['charge']}}" type="number">
                            <label for="charge" class="label">Charge</label>
                            <span class="invalid-feedback mt-5">{{$data['charge_error']}}</span>
                        </div>







                        {{--<div class="form-group"><label>Cover Pic</label>--}}
                        {{--<input type="file" id="photo" name="cover_pic" class="form-control student-photo {{(!empty($data['cover_pic_error']))? 'is-invalid':''}}">
                    </div>--}}
                    {{--<input type="button" name="browse_file" id="browse_file" class="form-control btn-infobtn-browse" value="browse">--}}
                    {{--<span class="invalid-feedback">{{$data['cover_pic_error']}}</span>--}}
                    {{--</div>--}}

                    {{--<div class="form-group"><label>Profile Pic</label>--}}
                    {{--<input class="form-control {{(!empty($data['profile_pic_error']))? 'is-invalid':''}}" name="profile_pic" type="file">--}}
                    {{--<span class="invalid-feedback">{{$data['profile_pic_error']}}</span>--}}
                    {{--</div>--}}



                </div>
        </div>



        <div class="row mx-auto mb-5">
            <div class=" col-md-12">
                <div class="form-group py-4 mt-5">
                    <textarea placeholder="Short description" rows=5 name="description" class="form-control input  {{(!empty($data['description_error']))? 'is-invalid':''}}">{{$data['description']}}</textarea>
                    <span class="invalid-feedback mt-5">{{$data['description_error']}}</span>
                </div>
            </div>
        </div>


        <div class="row mx-auto mb-5">

            <div class="col-md-6">
                <div class="form-group py-4">
                    <table style="margin: 0 auto;">

                        <td class="photo mx-auto">

                            <img class="student-photo" id="showPhoto">
                            <input type="file" name="cover_pic" id="photo" accept="image/x-png,image/png,image/jpg,image/jpeg">
                        </td>


                        <tr>
                            <td style="text-align: center;background: #ddd;">
                                <input type="button" name="browse_file" id="browse_file" class="form-control btn-info btn-browse" value="Cover Pic">
                            </td>
                        </tr>
                        </tbody>

                    </table>

                </div>
            </div>


            <div class="col-md-6">
                <div class="form-group py-4">
                    <table style="margin: 0 auto;">
                        <td class="photo">

                            <img class="student-photo" id="showProfilePhoto">
                            <input type="file" name="profile_pic" id="profile_photo" accept="image/x-png,image/png,image/jpg,image/jpeg">
                        </td>


                        <tr>
                            <td style="text-align: center;background: #ddd;">
                                <input type="button" name="browse_profile_file" id="browse_profile_file" class="form-control btn-info btn-browse" value="Profile Pic">
                            </td>
                        </tr>
                        </tbody>

                    </table>

                </div>
            </div>


        </div>


        <div class="col-md4 mx-auto text-center">
            <div class="form-group py-4 mt-5">
                <label for="terms">
                    <input class="form-check-label" name="terms" id="terms" @if($data['terms']) checked="checked" @endif type="checkbox">
                    <span>
                        <!-- Button trigger modal -->
                        I have read and accpeted the
                        <button type="button" class="btn btn-link" data-toggle="modal" data-target="#exampleModalScrollable">
                Terms & conditions
                        </button>
                    </span>
                </label>
                <span class="invalid-feedback mt-5">{{$data['terms_error']}}</span>

            </div>
        </div>



        <!-- Modal -->
        <div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable modal-xl animated slideInLeft " role="document">
                <div class="modal-content" style="border-radius:0">
                    <div class="modal-header text-center">
                        <h5 class="modal-title text-center" id="exampleModalScrollableTitle">Terms and conditions of use</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="container-fluid">
                            <h3 class="text-capitalize">Description</h3>
                            <p class="justify-left lead" style="font-size:12px">BLEM ENTERTAINMENT is a booking agency listing Disk jockeys, Dj producers and live bands. Our main objective is to bridge the gap between the above listed service providers with potential clients.</p>

                            <hr>

                            <h3 class="text-capitalize">General Terms and Conditions</h3>
                            <p class="justify-left lead" style="font-size:12px">
                                This is a legal agreement ("Agreement") between and among you and BLEM ENTERTAINMENT (stating the terms that govern your (i.e., customer, registered user, website visitor, artist, dancer, client, label, brand, etc.) use of BLEM websites, by using the Website, you agree to and are bound by the terms of this Agreement. You must accept and abide by these terms as presented to you, BLEM ENTERTAINMENT reserves the right to change, add, or remove portions of this Agreement at any time. It is your responsibility to check the Agreement each time before using the Website, and your continued use of the Website will indicate your acceptance of any changes. In addition, you agree to comply with all local, state, national, and international laws, statutes, ordinances, and regulations that apply to your use of the Website or Content (defined below).
                            </p>

                            <h3 class="text-capitalize">General Terms and Conditions</h3>
                            <p class="justify-left lead" style="font-size:12px">
                                In order to use the Product(s) or services offered on this Website, you need to (a) be 18 or older, or be 13 or older and have your parent or guardian’s consent to the terms of this Agreement, and (b) have the power to enter a binding contract with us and are not barred from doing so under any applicable laws. If there are parts of this Website or services being offered on the Website where you need to register and provide certain information to BLEM ENTERTAINMENT: You must be at least 18 years of age. If you are at least 13 years of age, but under 18 years of age, you must present this Agreement to your parent or legal guardian, and he or she must click "AGREE" or “SIGN UP,” as may be applicable, to enter into this Agreement on your behalf. Children under 13 years of age may not register for the Website, nor may parents or legal guardians register on their behalf. If you are a parent or legal guardian entering this Agreement for the benefit of your child or a child in your legal care, be aware that you are fully responsible for the child's use of the Website, including all financial charges and legal liability that he or she may incur.
                            </p>

                            <h3 class="text-capitalize">Account Registration.</h3>
                            <p class="justify-left lead" style="font-size:12px">
                                (a) To use certain services of the Website you must register and provide certain information (e.g. a member/client name, billing information, and valid email address) to BLEM ("Registration Data"). You agree to provide current, complete, and accurate Registration Data at the time you register and you will update your Registration Data as necessary to keep it current, complete and accurate. BLEM may terminate your use and any or all rights to the Website if any information you provide is inaccurate, false, incomplete, or, if BLEM, in its own discretion, suspects fraudulent and/or illegal behaviour, such as but not limited to identify theft, stolen credit cards, or artificial purchasing to inflate sales data, associated with your registration. You agree that BLEM may store and use the Registration Data you provide for use in billing fees to you and maintaining your information with us.
                                (b) You are solely responsible for maintaining the confidentiality and security of your information provided to us. You agree to notify BLEM immediately of any unauthorized use of your information provided to us. BLEM shall not be responsible for any losses arising out of the unauthorized use of your Registration Data, and you agree to hold harmless and to indemnify BLEM, its partners, parents, subsidiaries, agents, members, affiliates and/or licensors, as applicable, for any improper, unauthorized or illegal uses of your information. You may not attempt to gain unauthorized access to the Website. Should you attempt to do so, assist others in making such attempts, or distributing instructions, software or tools for that purpose, BLEM shall have the right to terminate your information and pursue all available remedies at law.
                            </p>

                            <h3 class="text-capitalize">Consent to our communication with you by E-Mail.</h3>
                            <p class="justify-left lead" style="font-size:12px">
                                By establishing your information, you grant permission for BLEM to contact you at your provided e-mail address as well as through any of your social media accounts (Facebook, Twitter, Instagram, Snapchat, etc.).
                            </p>


                            <h3 class="text-capitalize">Charges and Billing.</h3>
                            <p class="justify-left lead" style="font-size:12px">
                                The client will be allowed to pay with mobile money transfer or cash. This will be processed immediately in time of payment, the client is to pay an agreed amount of money as deposit at an agreed time and the remaining instalment at the agreed time frame. In case the entertainer does not deliver service due to reason from BLEM ENTERTAINMENT the client will be fully refunded. This is to take place in a maximum of 14 working days
                                The Deejay will receive payment in a method he or she desires only if it does not add an extra cost to BLEM ENTERTAINMENT, The entertainer will receive payment after service delivery, this will be less 20% of the agreed amount between the Deejay and BLEM ENTERTAINMENT.

                            </p>


                            <h3 class="text-capitalize">Right to Change Prices and Content Availability.</h3>
                            <p class="justify-left lead" style="font-size:12px">
                                Prices and availability of Content offered through the Website are subject to change at any time. BLEM does not provide price protection or refunds in the event of a price drop or promotional offering.

                            </p>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

                    </div>
                </div>
            </div>
        </div>


        <div class=" row mx-auto">
            <div class="col-md-12">
                <button class="btn btn-lg float-right btn-primary mb-3 mt-3" type="submit" name="submit">Register</button>
                <button class="btn btn-lg float-left btn-danger mb-3 mt-3" type="reset" name="reset">Cancel</button>
            </div>
        </div>


        </form>
    </div>
    </div>

    </div>
</section>
@endsection