<?php
namespace App\Views;
use Jenssegers\Blade\Blade;

class View
{
    public static function renderer($view,$args=[])
    {
        extract($args,EXTR_SKIP);
        $file="../App/Views/$view"; #path to views folder
        if (is_readable($file)) {
            require $file;
        }else {
            echo "The View $file not found";
        }
    }






    // render Views using Blade
    public static function renderTemplate($template, $data = [])
    {
        echo static::returnTemplate($template,$data);

    }



    // render Views using Blade
    public static function returnTemplate($template, $data = [])
    {
        $blade = new Blade(BASE_PATH.'/resources/views/', BASE_PATH.'/storage/views/cache/');
        $file = BASE_PATH.'/resources/views/' . $template . '.blade.php';

        if (file_exists($file)) {
            return $blade->render($template, $data);

        }
        else {
            echo "The view" . " " . $template . " " . "Does not exist in path" . " " . $file;
        }


    }


    public static function make($template,$data){

        extract($data);

        ob_start();

       include(BASE_PATH.'/resources/views/mail/' . $template . '.blade.php');
       $content=ob_get_contents();
       ob_end_clean();

       return $content;

    }





    public static function render($template,$args=[])
    {
        $twig=null;
        if ($twig===null) {
            $loader = new \Twig_Loader_Filesystem('../App/Views');
            $twig = new \Twig_Environment($loader);
        }
        echo $twig->render($template,$args);
    }


}