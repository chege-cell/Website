<?php
require_once __DIR__.'/../../vendor/autoload.php';

//DB PARAMS
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','blem');

//App root
define ('APPROOT',dirname(dirname(__FILE__)));
//App base url
define ('URL_ROOT','http://localhost/blem');

define('APP_FILE_URL','localhost\blem');
//App name
define ('SITENAME','BLEM');

define('SECRET_KEY','Sxhtgwj5688whsnajshrbstudbjsuwrtys');




define('BASE_PATH',realpath(__DIR__.'/../../'));

$dotEnv = \Dotenv\Dotenv::create(BASE_PATH);
$dotEnv->load();





